package org.example;

import java.util.LinkedList;
import java.io.Serializable;
import java.util.Date;

public class Schedule implements Serializable {
    private static final long serialVersionUID = 2L;


    private Doctor doctor ;
    private LinkedList<Rendezvous> sessions;
    private int maxPatientPerDay ;

    public LinkedList<Rendezvous> getSessions() {
        return sessions;
    }

    public Schedule(int maxPatientPerDay) {
        sessions = new LinkedList<>();
        this.maxPatientPerDay = maxPatientPerDay;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
        if(doctor.getSchedule() == null ){
            doctor.setSchedule(this);
        }
    }

    public int getMaxPatientPerDay() {
        return maxPatientPerDay;
    }

    public void setMaxPatientPerDay(int maxPatientPerDay) {
        this.maxPatientPerDay = maxPatientPerDay;
    }

    public boolean addRendezvous(Patient p , Date desired ){
        int i =0 ;
        for (Rendezvous r : sessions){

            if(r.getDateTime().equals(desired)){
                i++;
                System.out.println(" Bugunku randevu sayisi :"  + i);
            }
        }
        System.out.println(desired + " day "+ doctor +" has " + i + " patient . " + " Max : " + maxPatientPerDay);
        if( i == maxPatientPerDay){
            System.out.println("Error : Max patient per day !!");
            return false;
        }
        else {
            Rendezvous r2 = new Rendezvous(desired, p, doctor);
            sessions.add(r2);
            System.out.println("Rendezvous succesfully added !!");
            return true;
        }
    }






}
