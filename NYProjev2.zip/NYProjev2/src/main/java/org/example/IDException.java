package org.example;

public class IDException extends RuntimeException {
  public IDException(String message) {
    super(message);
  }
}