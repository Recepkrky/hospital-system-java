package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.example.CRS.findHospitalById;
import static org.example.CRS.findPatientByID;

public class GUI {

    private CRS crs = new CRS(); // CRS nesnesi
    private JFrame mainFrame, managerFrame;
    private JTabbedPane tabbedPane;

    public static void main(String[] args) {
        new GUI().start();
    }

    public static boolean arePatientIDSequal(HashMap<Long,Patient> patientHashMap , long longvalue) throws DuplicateInfoException {
        for (Long value : patientHashMap.keySet()) {
            if (Person.areIDequals(longvalue, value)) {
                throw new DuplicateInfoException("-Duplicate-");
            }
        }
        return true;
    }

    public void start() {
        initializeCRS(); // CRS verilerini başlat
        createMainFrame(); // Ana ekranı oluştur
        CRS.setGUIMode(true);
    }

    private void initializeCRS() {
        // Örnek veri yapıları
        Date date = new Date();

        // Hastalar
        crs.getPatients().put(1L, new Patient("RECEP", 1));
        crs.getPatients().put(2L, new Patient("TURAN", 2));
        crs.getPatients().put(3L, new Patient("TOLGA", 3));

        // Hastane ve bölümler
        Hospital hospital1 = new Hospital(1);
        hospital1.setName("Bursa Devlet Hastanesi ");
        crs.getHospitals().put(1, hospital1);

        Hospital hospital2 = new Hospital(2);
        hospital2.setName("Bursa Sevket Yilmaz Hastanesi");
        crs.getHospitals().put(2, hospital2);

        Section section1 = new Section(10);
        section1.setName("KBB");
        hospital1.getSections().add(section1);

        Section section2 = new Section(11);
        section2.setName("Kalp Cerrahisi");
        hospital1.getSections().add(section2);

        Section section3 = new Section(20);
        section3.setName("Dis");
        hospital2.getSections().add(section3);

        Doctor doctor1 = new Doctor("BARIS", 12, 100,1);
        section1.addDoctor(doctor1);

        Doctor doctor2 = new Doctor("ALI BILAL", 13, 200,1);
        section2.addDoctor(doctor2);

        Doctor doctor3 = new Doctor("FURKAN", 14, 101,1);
        section1.addDoctor(doctor3);

        Schedule schedule1 = new Schedule(doctor1.getSchedule().getMaxPatientPerDay());
        doctor1.setSchedule(schedule1);

        schedule1.addRendezvous(new Patient("Recep", 1), date);


        Rendezvous R = new Rendezvous(date,new Patient("RECEP", 1),doctor1);
        crs.getRendezvous().add(R);

    }

    private void createMainFrame() {
        mainFrame = new JFrame("Hospital Management System");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(600, 400);
        mainFrame.setLayout(null);

        JLabel title = new JLabel("Hospital Management System", SwingConstants.CENTER);
        title.setBounds(50, 20, 500, 30);
        mainFrame.add(title);

        JButton managerButton = new JButton("Manager");
        managerButton.setBounds(200, 80, 200, 50);
        managerButton.addActionListener(e -> {
            createManagerFrame();
            managerFrame.setVisible(true);
            mainFrame.setVisible(false);
        });
        mainFrame.add(managerButton);

        JButton saveLoadButton = new JButton("Save/Load");
        saveLoadButton.setBounds(200, 160, 200, 50);

        mainFrame.add(saveLoadButton);

        saveLoadButton.addActionListener(e -> saveLoad());

        JButton exitButton = new JButton("Exit");
        exitButton.setBounds(250, 250, 100, 20);
        exitButton.addActionListener(e -> System.exit(0));
        mainFrame.add(exitButton);

        mainFrame.setVisible(true);
    }

    private void createManagerFrame() {
        if (managerFrame != null) return; // Eğer zaten oluşturulmuşsa tekrar oluşturma

        managerFrame = new JFrame("Manager");
        managerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        managerFrame.setSize(800, 600);

        tabbedPane = new JTabbedPane();
        tabbedPane.add("Patients", createPatientsPanel());
        tabbedPane.add("Hospitals", createHospitalsPanel());
        tabbedPane.add("Rendezvous", createRendezvousPanel());

        managerFrame.add(tabbedPane);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            managerFrame.setVisible(false);
            mainFrame.setVisible(true);
        });
        managerFrame.add(backButton, BorderLayout.SOUTH);
    }

    private JPanel createPatientsPanel() {
        JPanel patientsPanel = new JPanel(new BorderLayout());
        String[] columnNames = {"Name", "National ID"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        // HashMap verilerini tabloya ekle
        for (Long id : crs.getPatients().keySet()) {
            Patient patient = crs.getPatients().get(id);
            tableModel.addRow(new Object[]{patient.getName(), patient.getNational_id()});
        }

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        patientsPanel.add(scrollPane, BorderLayout.CENTER);

        JButton addPatientButton = new JButton("ADD PATIENT");
        JButton removePatientButton = new JButton("REMOVE PATIENT");
        JButton refreshButton = new JButton("REFRESH");


        addPatientButton.addActionListener(e -> addPatient(tableModel));
        removePatientButton.addActionListener(e -> removePatient(tableModel));
        refreshButton.addActionListener(e -> refreshPatients(tableModel));

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        // Butonları buttonPanel'e ekle
        buttonPanel.add(addPatientButton);
        buttonPanel.add(removePatientButton);
        buttonPanel.add(refreshButton);

        // Patients paneline buttonPanel'i ekle
        patientsPanel.add(buttonPanel, BorderLayout.SOUTH);

        return patientsPanel;
    }

    private JPanel createRendezvousPanel() {
        JPanel rendezvousPanel = new JPanel(new BorderLayout());
        String[] columns = {"Patient Name(ID)", "Doctor Name(ID)", "Section Name(ID)", "Hospital Name(ID)", "Date"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);

        // Verileri tabloya ekle
        for (Hospital h : crs.getHospitals().values()) {
            for (Section s : h.getSections()) {
                for (Doctor d : s.getDoctorList()) {
                    for (Rendezvous r : d.getSchedule().getSessions()) {
                        tableModel.addRow(new Object[]{
                                r.getPatient().getName() + " (" + r.getPatient().getNational_id() + ")", // Patient Name + ID
                                d.getName() + " (" + d.getDiploma_id() + ")", // Doctor Name + Diploma ID
                                s.getName() + " (" + s.getId() + ")", // Section Name + ID
                                h.getName() + " (" + h.getId() + ")", // Hospital Name + ID
                                new SimpleDateFormat("EEE-HH:mm-ddMMMyyyy", Locale.ENGLISH).format(r.getDateTime())
                        });
                    }
                }
            }
        }

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        rendezvousPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addRendezvousButton = new JButton("ADD RENDEZVOUS");
        JButton removeRendezvousButton = new JButton("REMOVE RENDEZVOUS");
        JButton refreshButton = new JButton("REFRESH");

        addRendezvousButton.addActionListener(e -> addRendezvous(tableModel));
        removeRendezvousButton.addActionListener(e -> removeRendezvous(tableModel));
        refreshButton.addActionListener(e ->refreshRendezvous(tableModel));

        buttonPanel.add(addRendezvousButton);
        buttonPanel.add(removeRendezvousButton);
        buttonPanel.add(refreshButton);
        rendezvousPanel.add(buttonPanel, BorderLayout.SOUTH);

        return rendezvousPanel;
    }

    private JPanel createHospitalsPanel(){

        // Hospitals sekmesi için panel
        JPanel hospitalsPanel = new JPanel(new BorderLayout());

        // Sol tarafta hastane listesini göstermek için JTree
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Hospitals");

        // HashMap'teki hastane verilerini yeniden ekle
        for (Hospital h : crs.getHospitals().values()) {
            DefaultMutableTreeNode hospitalNode = new DefaultMutableTreeNode("Hospital: " + h.getName() + " ID :" + h.getId());

            // Sectionları kontrol et
            if (!h.getSections().isEmpty()) {
                for (Section s : h.getSections()) {
                    DefaultMutableTreeNode sectionNode = new DefaultMutableTreeNode("Section: " + s.getName() +  " ID :" + s.getId());

                    // Eğer doktor varsa ekle, yoksa placeholder ekle
                    if (!s.getDoctorList().isEmpty()) {
                        for (Doctor d : s.getDoctorList()) {
                            DefaultMutableTreeNode doctorNode = new DefaultMutableTreeNode("Doctor: " + d.getName() + " ID :" + d.getDiploma_id() );
                            sectionNode.add(doctorNode); // Doktorları Section altına ekle
                        }
                    } else {
                        // Eğer doktor yoksa placeholder ekle
                        sectionNode.add(new DefaultMutableTreeNode("No Doctor Available"));
                    }

                    hospitalNode.add(sectionNode); // Section'ları Hospital altına ekle
                }
            } else {
                // Eğer section yoksa placeholder ekle
                hospitalNode.add(new DefaultMutableTreeNode("No Sections Available"));
            }

            root.add(hospitalNode); // Hastaneyi root'a ekle
        }

        JTree hospitalTree = new JTree(root);
        hospitalsPanel.add(new JScrollPane(hospitalTree), BorderLayout.CENTER);

        // Sağ tarafta butonlar
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 1, 10, 10));

        JButton addRemoveDoctorButton = new JButton("Add/Remove Doctor");
        JButton addRemoveSectionButton = new JButton("Add/Remove Section");
        JButton addRemoveHospitalButton = new JButton("Add/Remove Hospital");
        JButton refreshButton = new JButton("Refresh");

        // Butonlara "SONRADAN YAZILMAK ÜZERE" işlevlerini ekle
        //ADD-REMOVE DOCTOR
        addRemoveDoctorButton.addActionListener(e ->{
            addRemoveDoctor( root,  hospitalTree);
        }
        );

        //ADD-REMOVE SECTION
        addRemoveSectionButton.addActionListener(e -> {
            addRemoveSection(root,hospitalTree);
        });

        //ADD-REMOVE HOSPITAL
        addRemoveHospitalButton.addActionListener(e -> {
            addRemoveHospital(root,hospitalTree);
        });

        //
        refreshButton.addActionListener(e -> {
            refreshTree(root,hospitalTree);
            JOptionPane.showMessageDialog(hospitalsPanel, "REFRESH OPERATION SUCCESSFUL");
        });

        // Butonları sağ panele ekle
        buttonPanel.add(addRemoveDoctorButton);
        buttonPanel.add(addRemoveSectionButton);
        buttonPanel.add(addRemoveHospitalButton);
        buttonPanel.add(refreshButton);

        hospitalsPanel.add(buttonPanel, BorderLayout.EAST);

        // JTree'deki çift tıklama işlemi
        hospitalTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Çift tıklama kontrolü
                    TreePath path = hospitalTree.getPathForLocation(e.getX(), e.getY());
                    if (path != null) {
                        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) path.getLastPathComponent();
                        if (selectedNode.isLeaf()) {
                            JOptionPane.showMessageDialog(hospitalsPanel, "Selected: " + selectedNode.getUserObject());
                        }
                    }
                }
            }
        });
        return hospitalsPanel;
    }

    private void addPatient(DefaultTableModel tableModel) {
        JPanel panel = new JPanel(new GridLayout(2, 2));
        panel.add(new JLabel("Enter Patient Name:"));
        JTextField nameField = new JTextField();
        panel.add(nameField);
        panel.add(new JLabel("Enter National ID:"));
        JTextField idField = new JTextField();
        panel.add(idField);

        int result = JOptionPane.showConfirmDialog(managerFrame, panel, "Add Patient", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String nationalIDString = idField.getText().trim();

            if (!name.isEmpty() && !nationalIDString.isEmpty()) {

                try {
                    long nationalID = Long.parseLong(nationalIDString);
                    GUI.arePatientIDSequal(crs.getPatients(), nationalID);

                    // Tabloya ekle
                    tableModel.addRow(new Object[]{name, nationalID});

                    // HashMap'e ekleme işlemi
                    Patient newPatient = new Patient(name, nationalID);
                    crs.getPatients().put(nationalID, newPatient);

                    // Başarılı ekleme mesajını özel panel ile göster
                    JPanel messagePanel = new JPanel(new GridLayout(2, 1));
                    messagePanel.add(new JLabel("Person's Name: " + name));
                    messagePanel.add(new JLabel("National ID: " + nationalID));

                    JOptionPane.showMessageDialog(managerFrame, messagePanel, "Success", JOptionPane.PLAIN_MESSAGE);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(managerFrame, "Invalid National ID. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (DuplicateInfoException ex) {
                    JOptionPane.showMessageDialog(managerFrame, "This ID already exists in the patients' list. Please enter a different number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(managerFrame, "Patient name and National ID cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        ;
    }

    private void removePatient(DefaultTableModel tableModel) {
        JPanel inputPanel = new JPanel(new GridLayout(1, 2));
        inputPanel.add(new JLabel("Enter National ID to Remove:"));
        JTextField nationalIDField = new JTextField();
        inputPanel.add(nationalIDField);

        int result = JOptionPane.showConfirmDialog(managerFrame, inputPanel, "Remove Patient", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String nationalIDString = nationalIDField.getText().trim();
            if (!nationalIDString.isEmpty()) {
                try {
                    long nationalID = Long.parseLong(nationalIDString);

                    // HashMap'ten silme
                    if (crs.getPatients().containsKey(nationalID)) {
                        crs.getPatients().remove(nationalID);
                        Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                        while (iterator.hasNext()) {
                            Rendezvous r = iterator.next();
                            if (r.getPatient().getNational_id() == nationalID) {
                                iterator.remove(); // Elemanı listeden güvenli bir şekilde sil
                                System.out.println("Rendezvous removed: " + r);
                            }
                        }

                        for (Hospital h : crs.getHospitals().values()) {
                            for (Section s : h.getSections()) {
                                for (Doctor d : s.getDoctorList()) {
                                    Iterator<Rendezvous> iterator1 = d.getSchedule().getSessions().iterator();
                                    while (iterator1.hasNext()) {
                                        Rendezvous r = iterator1.next();
                                        if (r.getPatient().getNational_id() == nationalID) {
                                            iterator1.remove(); // Elemanı listeden güvenli bir şekilde sil
                                            System.out.println("Rendezvous removed: " + r);
                                        }
                                    }
                                }
                            }
                        }

                        // Tabloyu güncellemek için tabloyu tarıyoruz
                        boolean found = false;
                        for (int i = 0; i < tableModel.getRowCount(); i++) {
                            if ((long) tableModel.getValueAt(i, 1) == nationalID) {
                                tableModel.removeRow(i);
                                found = true;
                                break;
                            }
                        }

                        if (found) {
                            JPanel successPanel = new JPanel();
                            successPanel.add(new JLabel("Patient with National ID " + nationalID + " removed successfully."));
                            JOptionPane.showMessageDialog(managerFrame, successPanel, "Success", JOptionPane.PLAIN_MESSAGE);
                        }
                    } else {
                        JPanel notFoundPanel = new JPanel();
                        notFoundPanel.add(new JLabel("Patient with National ID " + nationalID + " not found in HashMap."));
                        JOptionPane.showMessageDialog(managerFrame, notFoundPanel, "Not Found", JOptionPane.PLAIN_MESSAGE);
                    }
                } catch (NumberFormatException ex) {
                    JPanel errorPanel = new JPanel();
                    errorPanel.add(new JLabel("Invalid National ID. Please enter a valid number."));
                    JOptionPane.showMessageDialog(managerFrame, errorPanel, "Error", JOptionPane.PLAIN_MESSAGE);
                }
            } else {
                JPanel emptyPanel = new JPanel();
                emptyPanel.add(new JLabel("National ID cannot be empty."));
                JOptionPane.showMessageDialog(managerFrame, emptyPanel, "Error", JOptionPane.PLAIN_MESSAGE);
            }
        }
    }

    private void addRendezvous(DefaultTableModel tableModel) {
        JPanel panel = new JPanel(new GridLayout(6, 2));

        panel.add(new JLabel("Enter Patient ID:"));
        JTextField patientIDField = new JTextField();
        panel.add(patientIDField);

        panel.add(new JLabel("Enter Hospital ID:"));
        JTextField hospitalIDField = new JTextField();
        panel.add(hospitalIDField);

        panel.add(new JLabel("Enter Section ID:"));
        JTextField sectionIDField = new JTextField();
        panel.add(sectionIDField);

        panel.add(new JLabel("Enter Diploma ID:"));
        JTextField diplomaIDField = new JTextField();
        panel.add(diplomaIDField);

        panel.add(new JLabel("Select Date (Day):"));
        JSpinner dateSpinner = new JSpinner(new SpinnerDateModel());
        SimpleDateFormat englishDateFormat = new SimpleDateFormat("yyyy-MM-dd EE", Locale.ENGLISH);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, englishDateFormat.toPattern());
        dateSpinner.setEditor(dateEditor);
        panel.add(dateSpinner);

        panel.add(new JLabel("Select Time (Hour):"));
        String[] availableHours = {"09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"};
        JComboBox<String> timeComboBox = new JComboBox<>(availableHours);
        panel.add(timeComboBox);

        int result = JOptionPane.showConfirmDialog(managerFrame, panel, "Add Rendezvous", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String patientID = patientIDField.getText().trim();
            String hospitalID = hospitalIDField.getText().trim();
            String sectionID = sectionIDField.getText().trim();
            String diplomaID = diplomaIDField.getText().trim();
            Date selectedDate = (Date) dateSpinner.getValue();
            String selectedTime = (String) timeComboBox.getSelectedItem();

            if (!patientID.isEmpty() && !hospitalID.isEmpty() && !sectionID.isEmpty() && !diplomaID.isEmpty()) {
                // Formatlı tarih ve saat
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = dateFormat.format(selectedDate);

                String rendezvousDateTime = formattedDate + " " + selectedTime;

                try {
                    // Patient ID'yi long'a çevir
                    long patientID1 = Long.parseLong(patientIDField.getText().trim());

                    // Diğer ID'leri int'e çevir
                    int hospitalID1 = Integer.parseInt(hospitalIDField.getText().trim());
                    int sectionID1 = Integer.parseInt(sectionIDField.getText().trim());
                    int diplomaID1 = Integer.parseInt(diplomaIDField.getText().trim());

                    // selectedDate ve selectedTime birleştirilerek Date'e çevrilir
                    Date selectedDate1 = (Date) dateSpinner.getValue(); // Takvimden alınan tarih
                    String selectedTime1 = (String) timeComboBox.getSelectedItem(); // Saat olarak seçilen değer (örneğin: "10:00")

                    // Tarih ve saat formatını birleştir
                    SimpleDateFormat fullDateFormat = new SimpleDateFormat("yyyy-MM-dd EEE HH:mm", Locale.ENGLISH);
                    SimpleDateFormat datePartFormat = new SimpleDateFormat("yyyy-MM-dd EEE", Locale.ENGLISH);
                    String combinedDateTime = datePartFormat.format(selectedDate1) + " " + selectedTime1;

                    // Birleştirilmiş tarihi Date tipine dönüştür
                    Date finalDate = fullDateFormat.parse(combinedDateTime);

                    // finalDate'in formatlanması
                    SimpleDateFormat desiredFormat = new SimpleDateFormat("EEE-HH:mm-ddMMMyyyy", Locale.ENGLISH);
                    String formattedDate1 = desiredFormat.format(finalDate);

                    if (crs.makeRandezvous(patientID1, hospitalID1, sectionID1, diplomaID1, finalDate) ) {
                        Patient patient1 = findPatientByID(crs.getPatients(), patientID1);
                        Hospital hospital1 = findHospitalById(crs.getHospitals(), hospitalID1);
                        Section section1 = hospital1.getSection(sectionID1);
                        Doctor doctor1 = section1.getDoctor(diplomaID1);

                        tableModel.addRow(new Object[]{
                                patient1.getName(), doctor1.getName(), section1.getName(), hospital1.getName(), formattedDate1
                        });
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "Max patient per day !!.", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (NumberFormatException exc) {
                    JOptionPane.showMessageDialog(null, "Invalid input! IDs must be numeric.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (IDException exc){
                    JOptionPane.showMessageDialog(null, "Invalid input! This ID doesn't exist.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception exc) {
                    JOptionPane.showMessageDialog(null, "An error occurred: " + exc.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }

                // Burada tabloya veya veritabanına ekleme yapabilirsin
            } else {
                JOptionPane.showMessageDialog(managerFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

    }

    private void  removeRendezvous(DefaultTableModel tableModel){

            JPanel panel = new JPanel(new GridLayout(2, 2));

            panel.add(new JLabel("Enter Patient Name:"));
            JTextField patientNameField = new JTextField();
            panel.add(patientNameField);

            panel.add(new JLabel("Enter Doctor Name:"));
            JTextField doctorNameField = new JTextField();
            panel.add(doctorNameField);

            // Diyalog penceresi aç
            int result = JOptionPane.showConfirmDialog(
                    managerFrame,
                    panel,
                    "Remove Patient",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE
            );

            if (result == JOptionPane.OK_OPTION) {
                String patientName = patientNameField.getText().trim();
                String doctorName = doctorNameField.getText().trim();

                // Kullanıcıdan alınan değerlerin kontrolü
                if (!patientName.isEmpty() && !doctorName.isEmpty()) {
                    boolean foundAndRemoved = crs.removeRendezvous(patientName,doctorName,crs.getHospitals(),crs.getRendezvous());

                    // Silme işleminin sonucu
                    if (foundAndRemoved) {
                        JOptionPane.showMessageDialog(managerFrame, "Patient successfully removed.");
                        // Tabloyu güncellemek için kod (isteğe bağlı)
                    } else {
                        JOptionPane.showMessageDialog(managerFrame, "No matching patient found.");
                    }
                } else {
                    JOptionPane.showMessageDialog(managerFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }


    }

    private void refreshTree(DefaultMutableTreeNode root, JTree hospitalTree) {
        // JTree'yi yenilemek için refresh metodu
        // Root node'u sıfırla
        root.removeAllChildren();

        // HashMap'teki hastane verilerini yeniden ekle
        for (Hospital h : crs.getHospitals().values()) {
            DefaultMutableTreeNode hospitalNode = new DefaultMutableTreeNode("Hospital: " + h.getName() + " ID :" + h.getId());
            // Sectionları kontrol et
            if (!h.getSections().isEmpty()) {
                for (Section s : h.getSections()) {
                    DefaultMutableTreeNode sectionNode = new DefaultMutableTreeNode("Section: " + s.getName() + " ID :" + s.getId());

                    // Eğer doktor varsa ekle, yoksa placeholder ekle
                    if (!s.getDoctorList().isEmpty()) {
                        for (Doctor d : s.getDoctorList()) {
                            DefaultMutableTreeNode doctorNode = new DefaultMutableTreeNode("Doctor: " + d.getName() + " ID :" + d.getDiploma_id());
                            sectionNode.add(doctorNode); // Doktorları Section altına ekle
                        }
                    } else {
                        // Eğer doktor yoksa placeholder ekle
                        sectionNode.add(new DefaultMutableTreeNode("No Doctor Available"));
                    }

                    hospitalNode.add(sectionNode); // Section'ları Hospital altına ekle
                }
            } else {
                // Eğer section yoksa placeholder ekle
                hospitalNode.add(new DefaultMutableTreeNode("No Sections Available"));
            }

            root.add(hospitalNode); // Hastaneyi root'a ekle
        }

        // JTree modelini yenile
        ((DefaultTreeModel) hospitalTree.getModel()).reload();
    }

    private void refreshPatients(DefaultTableModel tableModel){
        // Tabloyu temizle
        tableModel.setRowCount(0);

        // HashMap'teki verileri tabloya yeniden ekle
        for (Long id : crs.getPatients().keySet()) {
            Patient patient = crs.getPatients().get(id);
            tableModel.addRow(new Object[]{patient.getName(), patient.getNational_id()});
        }
        JOptionPane.showMessageDialog(managerFrame, "Table refreshed successfully!", "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }

    private void refreshRendezvous(DefaultTableModel tableModel){
        // Tabloyu temizle
        tableModel.setRowCount(0);

        // Verileri tabloya tekrar ekle
        for (Hospital h : crs.getHospitals().values()) {
            for (Section s : h.getSections()) {
                for (Doctor d : s.getDoctorList()) {
                    for (Rendezvous r : d.getSchedule().getSessions()) {
                        tableModel.addRow(new Object[]{
                                r.getPatient().getName() + " (" + r.getPatient().getNational_id() + ")", // Patient Name + ID
                                d.getName() + " (" + d.getDiploma_id() + ")", // Doctor Name + Diploma ID
                                s.getName() + " (" + s.getId() + ")", // Section Name + ID
                                h.getName() + " (" + h.getId() + ")", // Hospital Name + ID
                                new SimpleDateFormat("EEE-HH:mm-ddMMMyyyy", Locale.ENGLISH).format(r.getDateTime())
                        });
                    }
                }
            }
        }
    }

    private void addRemoveHospital(DefaultMutableTreeNode root ,JTree hospitalTree ){
        {
            // Yeni bir pencere oluştur
            JFrame hospitalFrame = new JFrame("Add/Remove Hospital");
            hospitalFrame.setSize(400, 200);
            hospitalFrame.setLayout(new GridLayout(2, 1, 10, 10));
            hospitalFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // ADD HOSPITAL ve REMOVE HOSPITAL butonları
            JButton addHospitalButton = new JButton("ADD HOSPITAL");
            JButton removeHospitalButton = new JButton("REMOVE HOSPITAL");

            // ADD HOSPITAL butonuna tıklandığında yapılacaklar
            addHospitalButton.addActionListener(addEvent -> {

                // Hospital Frame'i kapat
                hospitalFrame.dispose();

                // Kullanıcıdan hastane bilgisi almak için panel oluştur
                JPanel addHospitalPanel = new JPanel(new GridLayout(2, 2, 10, 10));
                addHospitalPanel.add(new JLabel("Enter Hospital Name:"));
                JTextField nameField = new JTextField();
                addHospitalPanel.add(nameField);

                addHospitalPanel.add(new JLabel("Enter Hospital ID:"));
                JTextField idField = new JTextField();
                addHospitalPanel.add(idField);

                // Kullanıcıya bir input dialog aç
                int result = JOptionPane.showConfirmDialog(hospitalFrame, addHospitalPanel, "Add Hospital", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    String name = nameField.getText().trim();
                    String idString = idField.getText().trim();

                    if (!name.isEmpty() && !idString.isEmpty()) {
                        try {
                            // ID'yi integer'a dönüştür
                            int id = Integer.parseInt(idString);

                            // HashMap'e ekle
                            if (crs.getHospitals().containsKey(id)) {
                                JOptionPane.showMessageDialog(hospitalFrame, "Hospital with this ID already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                            } else {
                                crs.getHospitals().put(id, new Hospital(id,name));
                                JOptionPane.showMessageDialog(hospitalFrame, "Hospital added successfully!");

                                // JTree'yi yenile
                                refreshTree(root, hospitalTree);


                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(hospitalFrame, "Invalid ID. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(hospitalFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            // REMOVE HOSPITAL butonu için boş bir işlev (sonradan yazılacak)
            removeHospitalButton.addActionListener(removeEvent -> {

                hospitalFrame.dispose();

                // Kullanıcıdan hastane ID'si almak için input dialog
                String input = JOptionPane.showInputDialog(hospitalFrame, "Enter Hospital ID to Remove:", "Remove Hospital", JOptionPane.PLAIN_MESSAGE);

                if (input != null && !input.trim().isEmpty()) {
                    try {
                        int hospitalID = Integer.parseInt(input.trim());

                        // HashMap'te hastane kontrolü
                        if (crs.getHospitals().containsKey(hospitalID)) {

                            //rendezvoustaki randevulari sil
                            Hospital hospital16 =CRS.findHospitalById(crs.getHospitals(),hospitalID);
                                for (Section s : hospital16.getSections()) {
                                    for (Doctor d : s.getDoctorList()) {
                                        for (Rendezvous r : d.getSchedule().getSessions()) {
                                            Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                                            while (iterator.hasNext()) {
                                                Rendezvous r1 = iterator.next();
                                                if (r1.equals(r)) {
                                                    iterator.remove(); // Elemanı listeden güvenli bir şekilde sil
                                                    System.out.println("Rendezvous removed: " + r1);
                                                }
                                            }
                                        }
                                    }
                                }

                            // HashMap'ten hastaneyi kaldır
                            crs.getHospitals().remove(hospitalID);

                            // JTree'yi güncelle
                            refreshTree(root, hospitalTree);

                            JOptionPane.showMessageDialog(hospitalFrame, "Hospital removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(hospitalFrame, "Hospital ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(hospitalFrame, "Invalid ID! Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(hospitalFrame, "Hospital ID cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                }                    // Hospital Frame'i kapat
                hospitalFrame.dispose();
            });

            // Butonları pencereye ekle
            hospitalFrame.add(addHospitalButton);
            hospitalFrame.add(removeHospitalButton);

            // Pencereyi görünür yap
            hospitalFrame.setVisible(true);        }
    }

    private void addRemoveSection(DefaultMutableTreeNode root, JTree hospitalTree) {
        // Yeni bir pencere oluştur
        JFrame sectionFrame = new JFrame("Add/Remove Section");
        sectionFrame.setSize(400, 200);
        sectionFrame.setLayout(new GridLayout(2, 1, 10, 10));
        sectionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ADD SECTION ve REMOVE SECTION butonları
        JButton addSectionButton = new JButton("ADD SECTION");
        JButton removeSectionButton = new JButton("REMOVE SECTION");

        // ADD SECTION butonuna tıklandığında yapılacaklar
        addSectionButton.addActionListener(addEvent -> {
            // Section Frame'i kapat
            sectionFrame.dispose();

            // Kullanıcıdan section bilgisi almak için panel oluştur
            JPanel addSectionPanel = new JPanel(new GridLayout(3, 2, 10, 10));
            addSectionPanel.add(new JLabel("Enter Section Name:"));
            JTextField nameField = new JTextField();
            addSectionPanel.add(nameField);

            addSectionPanel.add(new JLabel("Enter Section ID:"));
            JTextField idField = new JTextField();
            addSectionPanel.add(idField);

            addSectionPanel.add(new JLabel("Enter Hospital ID:"));
            JTextField hospitalIdField = new JTextField();
            addSectionPanel.add(hospitalIdField);

            // Kullanıcıya bir input dialog aç
            int result = JOptionPane.showConfirmDialog(sectionFrame, addSectionPanel, "Add Section", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                String name = nameField.getText().trim();
                String idString = idField.getText().trim();
                String hospitalIdString = hospitalIdField.getText().trim();

                if (!name.isEmpty() && !idString.isEmpty() && !hospitalIdString.isEmpty()) {
                    try {
                        // ID'leri integer'a dönüştür
                        int sectionID = Integer.parseInt(idString);
                        int hospitalID = Integer.parseInt(hospitalIdString);

                        // Hastane kontrolü
                        if (crs.getHospitals().containsKey(hospitalID)) {
                            Hospital hospital = crs.getHospitals().get(hospitalID);

                            // Eğer aynı ID'ye sahip bir section varsa hata ver
                            if (hospital.getSections().stream().anyMatch(section -> section.getId() == sectionID)) {
                                JOptionPane.showMessageDialog(sectionFrame, "Section with this ID already exists in the hospital.", "Error", JOptionPane.ERROR_MESSAGE);
                            } else {
                                // Yeni section ekle
                                hospital.getSections().add(new Section(sectionID,name));
                                JOptionPane.showMessageDialog(sectionFrame, "Section added successfully!");

                                // JTree'yi yenile
                                refreshTree(root, hospitalTree);
                            }
                        } else {
                            JOptionPane.showMessageDialog(sectionFrame, "Hospital ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(sectionFrame, "Invalid ID(s). Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(sectionFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // REMOVE SECTION butonuna tıklandığında yapılacaklar
        removeSectionButton.addActionListener(removeEvent -> {
            sectionFrame.dispose();

            // Kullanıcıdan kaldırılacak Section ID ve Hospital ID'si için input dialog
            JPanel removeSectionPanel = new JPanel(new GridLayout(2, 2, 10, 10));
            removeSectionPanel.add(new JLabel("Enter Section ID:"));
            JTextField sectionIdField = new JTextField();
            removeSectionPanel.add(sectionIdField);

            removeSectionPanel.add(new JLabel("Enter Hospital ID:"));
            JTextField hospitalIdField = new JTextField();
            removeSectionPanel.add(hospitalIdField);

            // Kullanıcıya input dialog göster
            int result = JOptionPane.showConfirmDialog(sectionFrame, removeSectionPanel, "Remove Section", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                String sectionIdString = sectionIdField.getText().trim();
                String hospitalIdString = hospitalIdField.getText().trim();

                if (!sectionIdString.isEmpty() && !hospitalIdString.isEmpty()) {
                    try {
                        int sectionID = Integer.parseInt(sectionIdString);
                        int hospitalID = Integer.parseInt(hospitalIdString);

                        // Hastane kontrolü
                        if (crs.getHospitals().containsKey(hospitalID)) {
                            Hospital hospital = crs.getHospitals().get(hospitalID);

                            // Section kontrolü
                            Section sectionToRemove = hospital.getSections().stream()
                                    .filter(section -> section.getId() == sectionID)
                                    .findFirst()
                                    .orElse(null);

                            if (sectionToRemove != null) {
                                //rendezvoustaki randevulari sil
                                Hospital hospital16 =CRS.findHospitalById(crs.getHospitals(),hospitalID);
                                Section s = hospital16.getSection(sectionID);
                                    for (Doctor d : s.getDoctorList()) {
                                        for (Rendezvous r : d.getSchedule().getSessions()) {
                                            Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                                            while (iterator.hasNext()) {
                                                Rendezvous r1 = iterator.next();
                                                if (r1.equals(r)) {
                                                    iterator.remove(); // Elemanı listeden güvenli bir şekilde sil
                                                    System.out.println("Rendezvous removed: " + r1);
                                                }
                                            }
                                        }
                                    }


                                // Section'ı kaldır
                                hospital.getSections().remove(sectionToRemove);
                                JOptionPane.showMessageDialog(sectionFrame, "Section removed successfully!");

                                // JTree'yi yenile
                                refreshTree(root, hospitalTree);
                            } else {
                                JOptionPane.showMessageDialog(sectionFrame, "Section ID not found in the specified hospital.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(sectionFrame, "Hospital ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(sectionFrame, "Invalid ID(s). Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(sectionFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Butonları pencereye ekle
        sectionFrame.add(addSectionButton);
        sectionFrame.add(removeSectionButton);

        // Pencereyi görünür yap
        sectionFrame.setVisible(true);
    }

    private void addRemoveDoctor(DefaultMutableTreeNode root, JTree hospitalTree) {
        // Yeni bir pencere oluştur
        JFrame doctorFrame = new JFrame("Add/Remove Doctor");
        doctorFrame.setSize(400, 200);
        doctorFrame.setLayout(new GridLayout(2, 1, 10, 10));
        doctorFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ADD DOCTOR ve REMOVE DOCTOR butonları
        JButton addDoctorButton = new JButton("ADD DOCTOR");
        JButton removeDoctorButton = new JButton("REMOVE DOCTOR");

        // ADD DOCTOR butonuna tıklandığında yapılacaklar
        addDoctorButton.addActionListener(addEvent -> {
            // Doctor Frame'i kapat
            doctorFrame.dispose();

            // Kullanıcıdan doktor bilgisi almak için panel oluştur
            JPanel addDoctorPanel = new JPanel(new GridLayout(6, 2, 10, 10));
            addDoctorPanel.add(new JLabel("Enter Doctor Name:"));
            JTextField nameField = new JTextField();
            addDoctorPanel.add(nameField);

            addDoctorPanel.add(new JLabel("Enter Doctor National ID:"));
            JTextField nationalIdField = new JTextField();
            addDoctorPanel.add(nationalIdField);

            addDoctorPanel.add(new JLabel("Enter Doctor Diploma ID:"));
            JTextField diplomaIdField = new JTextField();
            addDoctorPanel.add(diplomaIdField);

            addDoctorPanel.add(new JLabel("Enter Max Patient Per Day (Optional):"));
            JTextField maxPatientField = new JTextField();
            addDoctorPanel.add(maxPatientField);

            addDoctorPanel.add(new JLabel("Enter Hospital ID:"));
            JTextField hospitalIdField = new JTextField();
            addDoctorPanel.add(hospitalIdField);

            addDoctorPanel.add(new JLabel("Enter Section ID:"));
            JTextField sectionIdField = new JTextField();
            addDoctorPanel.add(sectionIdField);

            // Kullanıcıya bir input dialog aç
            int result = JOptionPane.showConfirmDialog(doctorFrame, addDoctorPanel, "Add Doctor", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);


            String maxPatientString = maxPatientField.getText().trim();
            int maxPatientPerDay = 1; // Varsayılan değer

            if (!maxPatientString.isEmpty()) {
                try {
                    maxPatientPerDay = Integer.parseInt(maxPatientString); // Kullanıcının girdisini al
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(doctorFrame, "Invalid Max Patient Per Day. Default value (10) will be used.", "Warning", JOptionPane.WARNING_MESSAGE);
                }
            }

            if (result == JOptionPane.OK_OPTION) {
                String name = nameField.getText().trim();
                String nationalIdString = nationalIdField.getText().trim();
                String diplomaIdString = diplomaIdField.getText().trim();
                String hospitalIdString = hospitalIdField.getText().trim();
                String sectionIdString = sectionIdField.getText().trim();

                if (!name.isEmpty() && !nationalIdString.isEmpty() && !diplomaIdString.isEmpty() &&
                        !hospitalIdString.isEmpty() && !sectionIdString.isEmpty()) {
                    try {
                        // ID'leri uygun tiplere dönüştür
                        long nationalID = Long.parseLong(nationalIdString);
                        int diplomaID = Integer.parseInt(diplomaIdString);
                        int hospitalID = Integer.parseInt(hospitalIdString);
                        int sectionID = Integer.parseInt(sectionIdString);

                        // Hastane kontrolü
                        if (crs.getHospitals().containsKey(hospitalID)) {
                            Hospital hospital = crs.getHospitals().get(hospitalID);

                            // Section kontrolü
                            Section section = hospital.getSections().stream()
                                    .filter(sec -> sec.getId() == sectionID)
                                    .findFirst()
                                    .orElse(null);

                            if (section != null) {
                                // Diploma ID kontrolü
                                boolean exists = false;
                                for (Doctor dct : section.getDoctorList()) {
                                    if (dct.getDiploma_id() == diplomaID) {
                                        exists = true;
                                        break;
                                    }
                                }

                                if (exists) {
                                    JOptionPane.showMessageDialog(doctorFrame, "Doctor with this Diploma ID already exists in the section.", "Error", JOptionPane.ERROR_MESSAGE);
                                } else {
                                    // Yeni doktor ekle
                                    section.getDoctorList().add(new Doctor(name, nationalID, diplomaID,maxPatientPerDay));
                                    JOptionPane.showMessageDialog(doctorFrame, "Doctor added successfully!");

                                    // JTree'yi yenile
                                    refreshTree(root, hospitalTree);
                                }
                            } else {
                                JOptionPane.showMessageDialog(doctorFrame, "Section ID not found in the specified hospital.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(doctorFrame, "Hospital ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(doctorFrame, "Invalid ID(s). Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(doctorFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // REMOVE DOCTOR butonuna tıklandığında yapılacaklar
        removeDoctorButton.addActionListener(removeEvent -> {
            doctorFrame.dispose();

            // Kullanıcıdan kaldırılacak Doctor Diploma ID, Hospital ID ve Section ID için input dialog
            JPanel removeDoctorPanel = new JPanel(new GridLayout(3, 2, 10, 10));

            removeDoctorPanel.add(new JLabel("Enter Hospital ID:"));
            JTextField hospitalIdField = new JTextField();
            removeDoctorPanel.add(hospitalIdField);

            removeDoctorPanel.add(new JLabel("Enter Section ID:"));
            JTextField sectionIdField = new JTextField();
            removeDoctorPanel.add(sectionIdField);

            removeDoctorPanel.add(new JLabel("Enter Doctor Diploma ID:"));
            JTextField doctorDiplomaIdField = new JTextField();
            removeDoctorPanel.add(doctorDiplomaIdField);

            // Kullanıcıya input dialog göster
            int result = JOptionPane.showConfirmDialog(doctorFrame, removeDoctorPanel, "Remove Doctor", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                String diplomaIdString = doctorDiplomaIdField.getText().trim();
                String hospitalIdString = hospitalIdField.getText().trim();
                String sectionIdString = sectionIdField.getText().trim();

                if (!diplomaIdString.isEmpty() && !hospitalIdString.isEmpty() && !sectionIdString.isEmpty()) {
                    try {
                        int diplomaID = Integer.parseInt(diplomaIdString);
                        int hospitalID = Integer.parseInt(hospitalIdString);
                        int sectionID = Integer.parseInt(sectionIdString);

                        // Hastane kontrolü
                        if (crs.getHospitals().containsKey(hospitalID)) {
                            Hospital hospital = crs.getHospitals().get(hospitalID);

                            // Section kontrolü
                            Section section = hospital.getSections().stream()
                                    .filter(sec -> sec.getId() == sectionID)
                                    .findFirst()
                                    .orElse(null);

                            if (section != null) {
                                // Doktor kontrolü
                                Doctor doctorToRemove = section.getDoctorList().stream()
                                        .filter(doc -> doc.getDiploma_id() == diplomaID)
                                        .findFirst()
                                        .orElse(null);

                                if (doctorToRemove != null) {

                                    //rendezvoustaki randevulari sil
                                    Hospital hospital16 =CRS.findHospitalById(crs.getHospitals(),hospitalID);
                                    Section s = hospital16.getSection(sectionID);
                                    Doctor d = s.getDoctor(diplomaID);
                                        for (Rendezvous r : d.getSchedule().getSessions()) {
                                            Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                                            while (iterator.hasNext()) {
                                                Rendezvous r1 = iterator.next();
                                                if (r1.equals(r)) {
                                                    iterator.remove(); // Elemanı listeden güvenli bir şekilde sil
                                                    System.out.println("Rendezvous removed: " + r1);
                                                }
                                            }
                                        }




                                    // Doktoru kaldır
                                    section.getDoctorList().remove(doctorToRemove);
                                    JOptionPane.showMessageDialog(doctorFrame, "Doctor removed successfully!");

                                    // JTree'yi yenile
                                    refreshTree(root, hospitalTree);
                                } else {
                                    JOptionPane.showMessageDialog(doctorFrame, "Doctor Diploma ID not found in the specified section.", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            } else {
                                JOptionPane.showMessageDialog(doctorFrame, "Section ID not found in the specified hospital.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(doctorFrame, "Hospital ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(doctorFrame, "Invalid ID(s). Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(doctorFrame, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Butonları pencereye ekle
        doctorFrame.add(addDoctorButton);
        doctorFrame.add(removeDoctorButton);

        // Pencereyi görünür yap
        doctorFrame.setVisible(true);
    }

    private void saveLoad(){

            // Save/Load için yeni bir pencere oluştur
            JFrame saveLoadFrame = new JFrame("Save/Load Options");
            saveLoadFrame.setSize(300, 150);
            saveLoadFrame.setLayout(new GridLayout(2, 1, 10, 10));
            saveLoadFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Save ve Load butonları
            JButton saveButton = new JButton("Save");
            JButton loadButton = new JButton("Load");

            // Save butonuna tıklandığında yapılacak işlem
            saveButton.addActionListener(saveEvent -> {
                saveLoadFrame.dispose();

                // Dosya yolu sabit olarak tanımlanır
                String filePath = "/Users/recepkarakaya/IdeaProjects/NYProjev2/mydata1.ser" ;

                try {
                    // Verileri kaydet
                    crs.saveTablesToDisk(filePath);
                    // Mesaj içeriği için bir JPanel oluşturun
                    JPanel messagePanel = new JPanel(new BorderLayout());
                    messagePanel.add(new JLabel("Data saved successfully to: " + filePath), BorderLayout.CENTER);

                    // JOptionPane ile özel bir mesaj gösterin (simge olmadan)
                    JOptionPane.showMessageDialog(null, messagePanel, "Success", JOptionPane.PLAIN_MESSAGE);

                } catch (Exception ex) {
                    // Mesaj içeriği için bir JPanel oluşturun
                    JPanel errorPanel = new JPanel(new BorderLayout());
                    errorPanel.add(new JLabel("An error occurred while saving: " + ex.getMessage()), BorderLayout.CENTER);

                    // JOptionPane ile özel bir mesaj gösterin (simge olmadan)
                    JOptionPane.showMessageDialog(null, errorPanel, "Error", JOptionPane.PLAIN_MESSAGE);                }
            });

            // Load butonuna tıklandığında yapılacak işlem
            loadButton.addActionListener(loadEvent -> {
                saveLoadFrame.dispose();

                // Dosya yolu sabit olarak tanımlanır
                String filePath = "/Users/recepkarakaya/IdeaProjects/NYProjev2/mydata1.ser";

                try {
                    // Dosyadan verileri yükle
                    CRS newCRS = CRS.loadTablesToDisk(filePath);
                    if (newCRS != null) {
                        this.crs = newCRS; // Mevcut CRS nesnesini güncelleyin
                    }

                    // Mesaj içeriği için bir JPanel oluşturun
                    JPanel infoPanel = new JPanel(new BorderLayout());
                    infoPanel.add(new JLabel("Data loaded successfully from: " + filePath), BorderLayout.CENTER);

                    // JOptionPane ile özel bir mesaj gösterin (simge olmadan)
                    JOptionPane.showMessageDialog(null, infoPanel, "Success", JOptionPane.PLAIN_MESSAGE);                }
                catch (Exception ex) {
                    // Mesaj içeriği için bir JPanel oluşturun
                    JPanel errorPanel = new JPanel(new BorderLayout());
                    errorPanel.add(new JLabel("An error occurred while loading: " + ex.getMessage()), BorderLayout.CENTER);

                    // JOptionPane ile özel bir mesaj gösterin (simge olmadan)
                    JOptionPane.showMessageDialog(null, errorPanel, "Error", JOptionPane.PLAIN_MESSAGE);                }
            });

            // Save ve Load butonlarını pencereye ekle
            saveLoadFrame.add(saveButton);
            saveLoadFrame.add(loadButton);

            // Pencereyi görünür yap
            saveLoadFrame.setVisible(true);

    }
}