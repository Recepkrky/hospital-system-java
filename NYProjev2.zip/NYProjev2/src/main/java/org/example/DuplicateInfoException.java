package org.example;

public class DuplicateInfoException extends RuntimeException {
  public DuplicateInfoException(String message) {
    super(message);
  }
}