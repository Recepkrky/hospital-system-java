package org.example;

import java.io.Serializable ;

public class Person implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name ;
    private final long national_id;

    public Person(String name ,long nationalId) {
        this.name = name ;
        national_id = nationalId ;
    }

    public long getNational_id() {
        return national_id;
    }

    public String getName() {
        return name;
    }

    public static boolean areIDequals(long personID , long national_id){
        if(personID == national_id){
            return true;
        }
        else  return false;

    }

    @Override
    public String toString() {
        return "Person's Name : " + name + " National ID: "+ national_id;
    }
}

