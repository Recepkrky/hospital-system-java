package org.example;


public class Doctor extends Person {
    private final int diploma_id;
    private Schedule schedule ;

    public Doctor(String name, long nationalId , int diploma_id ,int maxPatientperday) {
        super(name, nationalId);
        this.diploma_id=diploma_id;
        this.schedule=new Schedule(maxPatientperday);
    }

    public void setSchedule(Schedule schedule) {
        this.schedule = schedule;
        if (schedule.getDoctor() == null) {
            schedule.setDoctor(this);
        }
    }

    public int getDiploma_id() {
        return diploma_id;
    }

    public Schedule getSchedule(){
        return schedule ;
    }

    @Override
    public String toString() {
        String personString = super.toString();
        personString = personString.replace("Person's Name : ", "Doctor's Name: ");
        return personString + " Diploma ID :" + diploma_id  ;
    }
}

