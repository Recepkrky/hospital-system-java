package org.example;

public class Patient extends Person{

    public Patient(String name, long national_Id) {
        super(name, national_Id);
    }

    public long getNational_id(){
        return super.getNational_id( );
    }

    public String getName(){
        return super.getName() ;
    }

}