package org.example;
import java.text.SimpleDateFormat;
import java.util.*;


public class Main {
    private static CRS crs = new CRS();
    private static final Scanner scanner = new Scanner(System.in); // Tek bir Scanner nesnesi kullanılır

    private static void initializeCRS() {
        // Örnek veri yapıları
        Date date = new Date();

        // Hastalar
        crs.getPatients().put(1L, new Patient("RECEP", 1));
        crs.getPatients().put(2L, new Patient("TURAN", 2));
        crs.getPatients().put(3L, new Patient("TOLGA", 3));

        // Hastane ve bölümler
        Hospital hospital1 = new Hospital(1);
        hospital1.setName("Bursa Devlet Hastanesi ");
        crs.getHospitals().put(1, hospital1);

        Hospital hospital2 = new Hospital(2);
        hospital2.setName("Bursa Sevket Yilmaz Hastanesi");
        crs.getHospitals().put(2, hospital2);

        Section section1 = new Section(10);
        section1.setName("KBB");
        hospital1.getSections().add(section1);

        Section section2 = new Section(11);
        section2.setName("Kalp Cerrahisi");
        hospital1.getSections().add(section2);

        Section section3 = new Section(20);
        section3.setName("Dis");
        hospital2.getSections().add(section3);

        Doctor doctor1 = new Doctor("SERDAR", 12, 100,1);
        section1.addDoctor(doctor1);

        Doctor doctor2 = new Doctor("ALI BILAL", 13, 200,1);
        section2.addDoctor(doctor2);

        Doctor doctor3 = new Doctor("FURKAN", 14, 101,1);
        section1.addDoctor(doctor3);

        Schedule schedule1 = new Schedule(doctor1.getSchedule().getMaxPatientPerDay());
        doctor1.setSchedule(schedule1);

        schedule1.addRendezvous(new Patient("RECEP", 1), date);
        schedule1.setDoctor(doctor1);

        Rendezvous R = new Rendezvous(date,new Patient("RECEP", 1),doctor1);
        crs.getRendezvous().add(R);
    }

    public static void main(String[] args) {

        System.out.println("=====================================");
        System.out.println("     Hospital Management System      ");
        System.out.println("=====================================");
        System.out.println("1. GUI Mode");
        System.out.println("2. Console Mode");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                GUI gui = new GUI();
                gui.start();
                break;
                case "2":
                    CRS.setGUIMode(false);
                    initializeCRS(); // CRS verilerini başlat
                    startmenu();
                    break;
        }

        scanner.close(); // Program sonunda Scanner kapatılır
    }

    public static void startmenu() {
        boolean running = true;

        while (running) {
            System.out.println("=====================================");
            System.out.println("     Hospital Management System      ");
            System.out.println("=====================================");
            System.out.println("1. Manager");
            System.out.println("2. Save/Load");
            System.out.println("3. Exit");
            System.out.print("Please choose an option: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    managerMenu();
                    break;
                    case "2":
                        saveLoad();
                        break;
                        case "3":
                            System.out.println("Exiting the program...");
                            running = false;
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void managerMenu(){
                System.out.println("You selected Manager.");

                System.out.println("1. Patients");
                System.out.println("2. Hospitals");
                System.out.println("3. Rendezvous");
                System.out.println("4. Back");

                String choice = scanner.nextLine();

                switch (choice) {
                    case "1":
                        patientsMenu();
                        break;
                    case "2":
                        hospitalMenu();
                        break;
                    case "3":
                        rendezvousMenu();
                        break;
                    case "4":
                        return; // Bir önceki menüye dön
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
    }

    private static void patientsMenu() {
                boolean running = true;

                while (running) {
                    System.out.println("=====================================");
                    System.out.println("         Patients Management         ");
                    System.out.println("=====================================");
                    System.out.println("1. Add Patient");
                    System.out.println("2. Remove Patient");
                    System.out.println("3. List Patients");
                    System.out.println("4. Back");
                    System.out.print("Choose an option: ");

                    String choice = scanner.nextLine();

                    switch (choice) {
                        case "1":
                            addPatient();
                            break;
                        case "2":
                            removePatient();
                            break;
                        case "3":
                            listPatients(crs.getPatients());
                            break;
                        case "4":
                            running = false;
                            break;
                        default:
                            System.out.println("Invalid option. Try again.");
                    }
                }
    }

    private static void hospitalMenu() {
                boolean running = true;

                while (running) {
                    System.out.println("=========================================");
                    System.out.println("         Hospital Management Menu        ");
                    System.out.println("=========================================");
                    System.out.println("1. List Hospitals");
                    System.out.println("2. Add/Remove Doctor");
                    System.out.println("3. Add/Remove Section");
                    System.out.println("4. Add/Remove Hospital");
                    System.out.println("5. Back");
                    System.out.print("Choose an option: ");

                    String choice = scanner.nextLine();

                    switch (choice) {
                        case "1":
                            listHospitals(crs);
                            break;
                        case "2":
                            addRemoveDoctor(crs);
                            break;
                        case "3":
                            addRemoveSection(crs);
                            break;
                        case "4":
                            addRemoveHospital(crs);
                            break;
                        case "5":
                            running = false;
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                }
    }

    private static void rendezvousMenu() {
                boolean running = true;

                while (running) {
                    System.out.println("=========================================");
                    System.out.println("       Rendezvous Management Menu        ");
                    System.out.println("=========================================");
                    System.out.println("1. List Rendezvous");
                    System.out.println("2. Add Rendezvous");
                    System.out.println("3. Remove Rendezvous");
                    System.out.println("4. Back");
                    System.out.print("Choose an option: ");

                    String choice = scanner.nextLine();

                    switch (choice) {
                        case "1":
                            listRendezvous(crs);
                            break;
                        case "2":
                            addRendezvous(crs);
                            break;
                        case "3":
                            removeRendezvous(crs);
                            break;
                        case "4":
                            running = false;
                            break;
                        default:
                            System.out.println("Invalid option. Try again.");
                    }
                }
    }

    public static void listRendezvous(CRS crs) {
        System.out.println("=========================================");
        System.out.println("           Rendezvous List               ");
        System.out.println("=========================================");

        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE-HH:mm-ddMMMyyyy", Locale.ENGLISH);

        for (Hospital h : crs.getHospitals().values()) {
            for (Section s : h.getSections()) {
                for (Doctor d : s.getDoctorList()) {
                    for (Rendezvous r : d.getSchedule().getSessions()) {
                        System.out.println("Patient: " + r.getPatient().getName() + " (" + r.getPatient().getNational_id() + ")");
                        System.out.println("Doctor: " + d.getName() + " (" + d.getDiploma_id() + ")");
                        System.out.println("Section: " + s.getName() + " (" + s.getId() + ")");
                        System.out.println("Hospital: " + h.getName() + " (" + h.getId() + ")");
                        System.out.println("Date: " + dateFormat.format(r.getDateTime()));
                        System.out.println("-----------------------------------------");
                    }
                }
            }
        }
    }

    public static void addRendezvous(CRS crs) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
            SimpleDateFormat fullDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH);
            SimpleDateFormat outputFormat = new SimpleDateFormat("EEE-HH:mm-ddMMMyyyy", Locale.ENGLISH);

            System.out.println("=== Add Rendezvous ===");

            try {
                // Kullanıcıdan gerekli bilgileri al
                System.out.print("Enter Patient ID: ");
                long patientID = Long.parseLong(scanner.nextLine().trim());

                System.out.print("Enter Hospital ID: ");
                int hospitalID = Integer.parseInt(scanner.nextLine().trim());

                System.out.print("Enter Section ID: ");
                int sectionID = Integer.parseInt(scanner.nextLine().trim());

                System.out.print("Enter Doctor Diploma ID: ");
                int diplomaID = Integer.parseInt(scanner.nextLine().trim());

                System.out.print("Enter Date (yyyy-MM-dd): ");
                String dateInput = scanner.nextLine().trim();
                Date selectedDate = dateFormat.parse(dateInput);

                System.out.println("Available Times: 09:00, 10:00, 11:00, 12:00, 13:00, 14:00, 15:00, 16:00");
                System.out.print("Enter Time (HH:mm): ");
                String timeInput = scanner.nextLine().trim();

                // Tarih ve saati birleştir
                String combinedDateTime = dateFormat.format(selectedDate) + " " + timeInput;
                Date finalDate = fullDateFormat.parse(combinedDateTime);

                // Randevu oluşturma
                if (crs.makeRandezvous(patientID, hospitalID, sectionID, diplomaID, finalDate)) {
                    Patient patient = CRS.findPatientByID(crs.getPatients(), patientID);
                    Hospital hospital = CRS.findHospitalById(crs.getHospitals(), hospitalID);
                    Section section = hospital.getSection(sectionID);
                    Doctor doctor = section.getDoctor(diplomaID);

                    System.out.println("Rendezvous added successfully!");
                    System.out.println("Patient: " + patient.getName() + " (" + patient.getNational_id() + ")");
                    System.out.println("Doctor: " + doctor.getName() + " (" + doctor.getDiploma_id() + ")");
                    System.out.println("Section: " + section.getName() + " (" + section.getId() + ")");
                    System.out.println("Hospital: " + hospital.getName() + " (" + hospital.getId() + ")");
                    System.out.println("Date: " + outputFormat.format(finalDate));
                } else {
                    System.out.println("Error: Maximum number of patients per day reached for this doctor.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid input. IDs must be numeric.");
            } catch (IDException e) {
                System.out.println("Error: This ID doesn't exist.");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

    public static void removeRendezvous(CRS crs) {

            System.out.println("=== Remove Rendezvous ===");

            // Kullanıcıdan giriş al
            System.out.print("Enter Patient Name: ");
            String patientName = scanner.nextLine().trim();

            System.out.print("Enter Doctor Name: ");
            String doctorName = scanner.nextLine().trim();

            // Girişlerin kontrolü
            if (!patientName.isEmpty() && !doctorName.isEmpty()) {
                // Silme işlemi
                boolean foundAndRemoved = crs.removeRendezvous(patientName, doctorName, crs.getHospitals(), crs.getRendezvous());

                // Silme işleminin sonucu
                if (foundAndRemoved) {
                    System.out.println("Rendezvous removed successfully!");
                } else {
                    System.out.println("No matching rendezvous found for the given Patient and Doctor.");
                }
            } else {
                System.out.println("Error: All fields must be filled!");
            }
    }

    private static void listHospitals(CRS crs) {
        System.out.println("=========================================");
        System.out.println("              Hospitals List             ");
        System.out.println("=========================================");
        if (crs.getHospitals().isEmpty()) {
            System.out.println("No Hospitals Available");
        } else {
            for (Hospital h : crs.getHospitals().values()) {
                System.out.println("Hospital: " + h.getName() + " (ID: " + h.getId() + ")");
                if (!h.getSections().isEmpty()) {
                    for (Section s : h.getSections()) {
                        System.out.println("  Section: " + s.getName() + " (ID: " + s.getId() + ")");
                        if (!s.getDoctorList().isEmpty()) {
                            for (Doctor d : s.getDoctorList()) {
                                System.out.println("    Doctor: " + d.getName() + " (ID: " + d.getDiploma_id() + ")");
                            }
                        } else {
                            System.out.println("    No Doctors Available");
                        }
                    }
                } else {
                    System.out.println("  No Sections Available");
                }
            }
        }
        System.out.println("=========================================");
    }

    private static void addRemoveDoctor(CRS crs) {

        System.out.println("1. ADD DOCTOR");
        System.out.println("2. REMOVE DOCTOR");

        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                addDoctor(crs);
                break;
            case "2":
                removeDoctor(crs);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void addRemoveSection(CRS crs) {

        System.out.println("1. ADD SECTION");
        System.out.println("2. REMOVE SECTION");

        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                addSection(crs);
                break;
            case "2":
                removeSection(crs);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void addRemoveHospital(CRS crs) {

        System.out.println("1. ADD HOSPITAL");
        System.out.println("2. REMOVE HOSPITAL");

        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                addHospital(crs);
                break;
            case "2":
                removeHospital(crs);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    public static void addDoctor(CRS crs) {

        System.out.println("=== Add Doctor ===");
        System.out.print("Enter Doctor Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter Doctor National ID: ");
        String nationalIdString = scanner.nextLine().trim();

        System.out.print("Enter Doctor Diploma ID: ");
        String diplomaIdString = scanner.nextLine().trim();

        System.out.print("Enter Max Patients Per Day (Optional, default is 1): ");
        String maxPatientString = scanner.nextLine().trim();
        int maxPatients = 1;

        if (!maxPatientString.isEmpty()) {
            try {
                maxPatients = Integer.parseInt(maxPatientString);
            } catch (NumberFormatException ex) {
                System.out.println("Invalid Max Patients. Default value (1) will be used.");
            }
        }

        System.out.print("Enter Hospital ID: ");
        String hospitalIdString = scanner.nextLine().trim();

        System.out.print("Enter Section ID: ");
        String sectionIdString = scanner.nextLine().trim();

        if (!name.isEmpty() && !nationalIdString.isEmpty() && !diplomaIdString.isEmpty() &&
                !hospitalIdString.isEmpty() && !sectionIdString.isEmpty()) {
            try {
                long nationalID = Long.parseLong(nationalIdString);
                int diplomaID = Integer.parseInt(diplomaIdString);
                int hospitalID = Integer.parseInt(hospitalIdString);
                int sectionID = Integer.parseInt(sectionIdString);

                // Hastane kontrolü
                if (crs.getHospitals().containsKey(hospitalID)) {
                    Hospital hospital = crs.getHospitals().get(hospitalID);

                    // Section kontrolü
                    Section section = hospital.getSections().stream()
                            .filter(sec -> sec.getId() == sectionID)
                            .findFirst()
                            .orElse(null);

                    if (section != null) {
                        // Diploma ID kontrolü
                        boolean exists = section.getDoctorList().stream()
                                .anyMatch(doc -> doc.getDiploma_id() == diplomaID);

                        if (exists) {
                            System.out.println("Error: Doctor with this Diploma ID already exists.");
                        } else {
                            // Yeni doktor ekle
                            section.getDoctorList().add(new Doctor(name, nationalID, diplomaID, maxPatients));
                            System.out.println("Doctor added successfully!");
                        }
                    } else {
                        System.out.println("Error: Section ID not found in the specified hospital.");
                    }
                } else {
                    System.out.println("Error: Hospital ID not found.");
                }
            } catch (NumberFormatException ex) {
                System.out.println("Error: Invalid input for IDs. Please enter valid numbers.");
            }
        } else {
            System.out.println("Error: All fields must be filled.");
        }
    }

    public static void removeDoctor(CRS crs) {

        System.out.println("=== Remove Doctor ===");
        System.out.print("Enter Hospital ID: ");
        String hospitalIdString = scanner.nextLine().trim();

        System.out.print("Enter Section ID: ");
        String sectionIdString = scanner.nextLine().trim();

        System.out.print("Enter Doctor Diploma ID: ");
        String diplomaIdString = scanner.nextLine().trim();

        if (!hospitalIdString.isEmpty() && !sectionIdString.isEmpty() && !diplomaIdString.isEmpty()) {
            try {
                int hospitalID = Integer.parseInt(hospitalIdString);
                int sectionID = Integer.parseInt(sectionIdString);
                int diplomaID = Integer.parseInt(diplomaIdString);

                // Hastane kontrolü
                if (crs.getHospitals().containsKey(hospitalID)) {
                    Hospital hospital = crs.getHospitals().get(hospitalID);

                    // Section kontrolü
                    Section section = hospital.getSections().stream()
                            .filter(sec -> sec.getId() == sectionID)
                            .findFirst()
                            .orElse(null);

                    if (section != null) {
                        // Doktor kontrolü
                        Doctor doctorToRemove = section.getDoctorList().stream()
                                .filter(doc -> doc.getDiploma_id() == diplomaID)
                                .findFirst()
                                .orElse(null);

                        if (doctorToRemove != null) {
                            // Randevuları kaldır
                            Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                            while (iterator.hasNext()) {
                                Rendezvous r = iterator.next();
                                if (doctorToRemove.equals(r.getDoctor())) {
                                    iterator.remove();
                                    System.out.println("Rendezvous removed: " + r);
                                }
                            }

                            // Doktoru kaldır
                            section.getDoctorList().remove(doctorToRemove);
                            System.out.println("Doctor removed successfully!");
                        } else {
                            System.out.println("Error: Doctor Diploma ID not found in the specified section.");
                        }
                    } else {
                        System.out.println("Error: Section ID not found in the specified hospital.");
                    }
                } else {
                    System.out.println("Error: Hospital ID not found.");
                }
            } catch (NumberFormatException ex) {
                System.out.println("Error: Invalid input for IDs. Please enter valid numbers.");
            }
        } else {
            System.out.println("Error: All fields must be filled.");
        }
    }

    private static void listPatients (HashMap<Long, Patient> patients) {

        System.out.println("=====================================");
        System.out.println("           Patients List             ");
        System.out.println("=====================================");
        if (patients.isEmpty()) {
            System.out.println("No patients available.");
        } else {
            for (Long id : patients.keySet()) {
                Patient patient = patients.get(id);
                System.out.println("ID: " + id + ", Name: " + patient.getName() );
            }
        }
        System.out.println("=====================================");

    }

    private static void addPatient() {

        System.out.print("Enter patient name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter patient national ID: ");
        String nationalIdInput = scanner.nextLine().trim();

        if (name.isEmpty() || nationalIdInput.isEmpty()) {
            System.out.println("Error: Patient name and National ID cannot be empty.");
            return;
        }

        try {
            long nationalId = Long.parseLong(nationalIdInput);

            // Check for duplicate National ID
            if (crs.getPatients().containsKey(nationalId)) {
                throw new DuplicateInfoException("This ID already exists in the patients' list.");
            }

            // Add patient to HashMap
            Patient newPatient = new Patient(name, nationalId);
            crs.getPatients().put(nationalId, newPatient);

            // Success message
            System.out.println("Patient successfully added!");
            System.out.println("Name: " + name);
            System.out.println("National ID: " + nationalId);

        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid National ID. Please enter a valid number.");
        } catch (DuplicateInfoException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static void removePatient() {


        System.out.print("Enter National ID to Remove: ");
        String nationalIDString = scanner.nextLine().trim();

        if (!nationalIDString.isEmpty()) {
            try {
                long nationalID = Long.parseLong(nationalIDString);

                // Hastayı HashMap'ten silme
                if (crs.getPatients().containsKey(nationalID)) {
                    crs.getPatients().remove(nationalID);
                    System.out.println("Patient with National ID " + nationalID + " removed from the list.");

                    // Rendezvous silme
                    Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                    while (iterator.hasNext()) {
                        Rendezvous r = iterator.next();
                        if (r.getPatient().getNational_id() == nationalID) {
                            iterator.remove();
                            System.out.println("Rendezvous removed: " + r);
                        }
                    }

                    // Hastanelerde ve doktor programında bulunan randevuları silme
                    for (Hospital h : crs.getHospitals().values()) {
                        for (Section s : h.getSections()) {
                            for (Doctor d : s.getDoctorList()) {
                                Iterator<Rendezvous> iterator1 = d.getSchedule().getSessions().iterator();
                                while (iterator1.hasNext()) {
                                    Rendezvous r = iterator1.next();
                                    if (r.getPatient().getNational_id() == nationalID) {
                                        iterator1.remove();
                                        System.out.println("Rendezvous removed: " + r);
                                    }
                                }
                            }
                        }
                    }

                } else {
                    System.out.println("Patient with National ID " + nationalID + " not found in the list.");
                }

            } catch (NumberFormatException ex) {
                System.out.println("Invalid National ID. Please enter a valid number.");
            }
        } else {
            System.out.println("National ID cannot be empty.");
        }
    }

    private static void saveLoad () {

            boolean running = true;

            while (running) {
                System.out.println("=====================================");
                System.out.println("          Save/Load Options          ");
                System.out.println("=====================================");
                System.out.println("1. Save Data");
                System.out.println("2. Load Data");
                System.out.println("3. Back to Main Menu");
                System.out.print("Choose an option: ");

                String choice = scanner.nextLine();

                switch (choice) {
                    case "1":
                        saveData(crs);
                        break;
                    case "2":
                        Main main =new Main();
                        main.loadData(crs);
                        break;
                    case "3":
                        System.out.println("Returning to Main Menu...");
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
    }

    private static void saveData(CRS crs) {
        // Sabit dosya yolu tanımlayın
        String filePath = "/Users/recepkarakaya/IdeaProjects/NYProjev2/mydata1.ser";

        try {
            // Verileri kaydet
            crs.saveTablesToDisk(filePath);
            System.out.println("Data saved successfully to: " + filePath);
        } catch (Exception ex) {
            System.out.println("An error occurred while saving: " + ex.getMessage());
        }
    }

    private void loadData(CRS crs) {
        // Sabit dosya yolu tanımlayın
        String filePath = "/Users/recepkarakaya/IdeaProjects/NYProjev2/mydata1.ser";

        try {
            // Dosyadan verileri yükle
            CRS newCRS = CRS.loadTablesToDisk(filePath);
            if (newCRS != null) {
                this.crs = newCRS; // Mevcut CRS nesnesini güncelleyin
                System.out.println("Data loaded successfully from: " + filePath);
            } else {
                System.out.println("Error: No data found in the file.");
            }
        } catch (Exception ex) {
            System.out.println("An error occurred while loading: " + ex.getMessage());
        }
    }

    public static void addSection(CRS crs) {

        System.out.println("=== Add Section ===");
        System.out.print("Enter Section Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter Section ID: ");
        String idString = scanner.nextLine().trim();

        System.out.print("Enter Hospital ID: ");
        String hospitalIdString = scanner.nextLine().trim();

        if (!name.isEmpty() && !idString.isEmpty() && !hospitalIdString.isEmpty()) {
            try {
                int sectionID = Integer.parseInt(idString);
                int hospitalID = Integer.parseInt(hospitalIdString);

                // Hastane kontrolü
                if (crs.getHospitals().containsKey(hospitalID)) {
                    Hospital hospital = crs.getHospitals().get(hospitalID);

                    // Aynı ID'ye sahip bir bölüm olup olmadığını kontrol et
                    boolean exists = hospital.getSections().stream()
                            .anyMatch(section -> section.getId() == sectionID);

                    if (exists) {
                        System.out.println("Error: Section with this ID already exists in the hospital.");
                    } else {
                        // Yeni bölüm ekle
                        hospital.getSections().add(new Section(sectionID, name));
                        System.out.println("Section added successfully!");
                    }
                } else {
                    System.out.println("Error: Hospital ID not found.");
                }
            } catch (NumberFormatException ex) {
                System.out.println("Error: Invalid ID(s). Please enter valid numbers.");
            }
        } else {
            System.out.println("Error: All fields must be filled.");
        }
    }

    public static void removeSection(CRS crs) {

        System.out.println("=== Remove Section ===");
        System.out.print("Enter Section ID: ");
        String sectionIdString = scanner.nextLine().trim();

        System.out.print("Enter Hospital ID: ");
        String hospitalIdString = scanner.nextLine().trim();

        if (!sectionIdString.isEmpty() && !hospitalIdString.isEmpty()) {
            try {
                int sectionID = Integer.parseInt(sectionIdString);
                int hospitalID = Integer.parseInt(hospitalIdString);

                // Hastane kontrolü
                if (crs.getHospitals().containsKey(hospitalID)) {
                    Hospital hospital = crs.getHospitals().get(hospitalID);

                    // Bölüm kontrolü
                    Section sectionToRemove = hospital.getSections().stream()
                            .filter(section -> section.getId() == sectionID)
                            .findFirst()
                            .orElse(null);

                    if (sectionToRemove != null) {
                        // Bölüm içindeki randevuları kaldır
                        for (Doctor doctor : sectionToRemove.getDoctorList()) {
                            Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                            while (iterator.hasNext()) {
                                Rendezvous r = iterator.next();
                                if (r.getDoctor().equals(doctor)) {
                                    iterator.remove();
                                    System.out.println("Rendezvous removed: " + r);
                                }
                            }
                        }

                        // Bölümü kaldır
                        hospital.getSections().remove(sectionToRemove);
                        System.out.println("Section removed successfully!");
                    } else {
                        System.out.println("Error: Section ID not found in the specified hospital.");
                    }
                } else {
                    System.out.println("Error: Hospital ID not found.");
                }
            } catch (NumberFormatException ex) {
                System.out.println("Error: Invalid ID(s). Please enter valid numbers.");
            }
        } else {
            System.out.println("Error: All fields must be filled.");
        }
    }

    public static void addHospital(CRS crs) {

        System.out.println("=== Add Hospital ===");
        System.out.print("Enter Hospital Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter Hospital ID: ");
        String idString = scanner.nextLine().trim();

        if (!name.isEmpty() && !idString.isEmpty()) {
            try {
                int id = Integer.parseInt(idString);

                // Hastane kontrolü
                if (crs.getHospitals().containsKey(id)) {
                    System.out.println("Error: Hospital with this ID already exists.");
                } else {
                    // Yeni hastane ekle
                    crs.getHospitals().put(id, new Hospital(id, name));
                    System.out.println("Hospital added successfully!");
                }
            } catch (NumberFormatException ex) {
                System.out.println("Error: Invalid ID. Please enter a valid number.");
            }
        } else {
            System.out.println("Error: All fields must be filled.");
        }
    }

    public static void removeHospital(CRS crs) {

        System.out.println("=== Remove Hospital ===");
        System.out.print("Enter Hospital ID: ");
        String idString = scanner.nextLine().trim();

        if (!idString.isEmpty()) {
            try {
                int hospitalID = Integer.parseInt(idString);

                // Hastane kontrolü
                if (crs.getHospitals().containsKey(hospitalID)) {
                    Hospital hospital = crs.getHospitals().get(hospitalID);

                    // Randevuları kaldır
                    for (Section section : hospital.getSections()) {
                        for (Doctor doctor : section.getDoctorList()) {
                            Iterator<Rendezvous> iterator = crs.getRendezvous().iterator();
                            while (iterator.hasNext()) {
                                Rendezvous rendezvous = iterator.next();
                                if (rendezvous.getDoctor().equals(doctor)) {
                                    iterator.remove();
                                    System.out.println("Rendezvous removed: " + rendezvous);
                                }
                            }
                        }
                    }

                    // Hastaneyi kaldır
                    crs.getHospitals().remove(hospitalID);
                    System.out.println("Hospital removed successfully!");
                } else {
                    System.out.println("Error: Hospital ID not found.");
                }
            } catch (NumberFormatException ex) {
                System.out.println("Error: Invalid ID. Please enter a valid number.");
            }
        } else {
            System.out.println("Error: Hospital ID cannot be empty.");
        }
    }







}



