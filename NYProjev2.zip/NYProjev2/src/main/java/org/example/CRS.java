package org.example;

import java.io.Serializable;
import java.util.*;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class CRS implements Serializable {

    private static final long serialVersionUID = 6L;

    private static boolean isGUIMode = false; // GUI modunda olup olmadığını kontrol eder

    public static void setGUIMode(boolean isGUIMode) {
        CRS.isGUIMode = isGUIMode;
    }

    public static boolean isGUIMode() {
        return isGUIMode;
    }

    private HashMap<Long, Patient> patients;
    private LinkedList<Rendezvous> rendezvous;
    private HashMap<Integer, Hospital> hospitals;

    public HashMap<Integer, Hospital> getHospitals() {
        return hospitals;
    }

    public LinkedList<Rendezvous> getRendezvous() {
        return rendezvous;
    }

    public HashMap<Long, Patient> getPatients() {
        return patients;
    }

    public CRS() {
        patients = new HashMap<>();
        hospitals = new HashMap<>();
        rendezvous = new LinkedList<>();
    }

    public static Patient findPatientByID(HashMap<Long, Patient> patientHashMap, long PatientID) throws IDException {
            if (!patientHashMap.containsKey(PatientID)) {
                throw new IDException("Patient with ID " + PatientID + " not found.");
            }
        return patientHashMap.get(PatientID);
    }

    public static Hospital findHospitalById(HashMap<Integer, Hospital> hospitalMap, int hospitalID) throws IDException {
            if (!hospitalMap.containsKey(hospitalID)) {
                throw new IDException("Hospital with ID " + hospitalID + " not found.");
            }
        return hospitalMap.get(hospitalID);
    }

    public boolean makeRandezvous(long patientID, int hospitalID, int sectionID, int diplamaID, Date desiredDate) throws  IDException{
        try {
            Hospital hospital = findHospitalById(hospitals, hospitalID);
            Section section1 = hospital.getSection(sectionID);
            Doctor doctor = section1.getDoctor(diplamaID);
            Patient patient = findPatientByID(patients, patientID);
            System.out.println(patient);
        } catch (IDException e) {
            if (!isGUIMode) {  // GUI modunda değilse hata mesajını göster
                System.out.println("Error: " + e.getMessage());
            }
            throw e;
        }

        Patient patient1 = findPatientByID(patients, patientID);
        Hospital hospital = findHospitalById(hospitals, hospitalID);
        Section section = hospital.getSection(sectionID);
        Doctor doctor1 = section.getDoctor(diplamaID);

        if (doctor1.getSchedule().addRendezvous(patient1, desiredDate)) {
            Rendezvous randezvous1 = new Rendezvous(desiredDate, patient1, section.getDoctor(diplamaID));
            rendezvous.add(randezvous1);
            System.out.println(" SUCCESS");
            System.out.println("---- RENDEZVOUS LIST ----");
            for (Rendezvous r : rendezvous) {
                System.out.println(r);
            }
            return true;
        }

        if (!isGUIMode) {  // GUI modunda değilse max hasta hatasını göster
            System.out.println("----Error: Max patient per day!!----");
        }
        return false;
    }

    public boolean removeRendezvous(String patientName , String doctorName,HashMap<Integer,Hospital> hospitalHashMap , LinkedList<Rendezvous> rendezvous1){

        boolean flag = false ;

        for (Hospital hospital : hospitalHashMap.values()) {
            for (Section section : hospital.getSections()) {
                for (Doctor doctor : section.getDoctorList()) {
                    if (doctor.getName().equalsIgnoreCase(doctorName)) {
                        // Randevular üzerinden hasta arama ve silme
                        // Multi - threading islemi
                        synchronized (doctor.getSchedule()) {
                            Iterator<Rendezvous> iterator = doctor.getSchedule().getSessions().iterator();
                            while (iterator.hasNext()) {
                                Rendezvous r = iterator.next();
                                if (r.getPatient().getName().equalsIgnoreCase(patientName)) {
                                    System.out.println(r);
                                    iterator.remove(); // Hasta silinir
                                    flag = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        // Iterator kullanarak gez ve objeyi bulup çıkar
        Iterator<Rendezvous> iterator = rendezvous1.iterator();
        while (iterator.hasNext()) {
            Rendezvous r = iterator.next();
            System.out.println(r);
            if (flag)
                if (r.getPatient().getName().equalsIgnoreCase(patientName) && r.getDoctor().getName().equalsIgnoreCase(doctorName)) {
                    iterator.remove(); // Objeyi LinkedList'ten çıkar
                    System.out.println("Rendezvous removed: " + r);
                    return true;
                }
        }

        return false ;

    }

    public void saveTablesToDisk(String fullPath) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fullPath))) {
            out.writeObject(this);  // Write the CRS object to the file
            System.out.println("Data serialized successfully.");
        } catch (IOException e) {
            if(!isGUIMode()){
                System.out.println("Error during serialization: " + e.getMessage());
            }
        }
    }

    public static CRS loadTablesToDisk(String fullPath) throws IDException,ClassNotFoundException{
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fullPath))) {
            System.out.println("Data deserialized succesfully. ");
            return (CRS) ois.readObject(); // Read and return the CRS object
        } catch (IOException | ClassNotFoundException e) {
            if(!isGUIMode()){
                System.out.println("Error during serialization: " + e.getMessage());
            }
            return null;
        }
    }

    public static void main(String[] args) {

    }
}