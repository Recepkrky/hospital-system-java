package org.example;

import java.io.Serializable ;
import java.util.LinkedList;

public class Hospital implements Serializable {
    private static final long serialVersionUID = 5L ;

    private final int id ;
    private String name ;
    private LinkedList<Section> sections;

    public Hospital(int id) {
        this.id = id;
        sections = new LinkedList<>();
    }

    public Hospital(int id , String name ) {
        this.id = id;
        this.name = name ;
        sections = new LinkedList<>();
    }

    public String getName() {
        return name;
    }

    public LinkedList<Section> getSections() {
        return sections;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public Section getSection(int id ) throws IDException{
        for (Section sct : sections){
            if( sct.getId() == id){
                return sct;
            }
        }
        throw new IDException(" -- This sectionID couldn't find--");
    }
    private Section getSection( String name ) {
        for (Section sct : sections){
            if(name == sct.getName()){
                return sct;
            }
        }
        return null ;
    }

    public boolean addSection (Section section){
        for(Section sct : sections){
            if(section.getId() == sct.getId() ){
                throw new  DuplicateInfoException("Two section has a same ID .") ;
            }
        }
        if(sections.add(section)){
            return true ;
        }
        else return false ;
    }

    @Override
    public String toString() {
        return "Hospital"  + " Name : " + name  + " ID : " +  id + " Sections : " + sections;
    }
}
