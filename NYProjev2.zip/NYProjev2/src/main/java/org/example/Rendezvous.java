package org.example;

import java.io.Serializable;
import java.util.Date;

public class Rendezvous implements Serializable {
    private static final long serialVersionUID = 3L;

    private Date dateTime;
    private Patient patient;
    private Doctor doctor ;

    public Rendezvous(Date dateTime,Patient patient,Doctor doctor) {
        this.dateTime = dateTime;
        this.patient = patient;
        this.doctor = doctor;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Date getDateTime() {
        return dateTime;
    }


    @Override
    public String toString() {
        return " Date: " + dateTime + " Patient: " + patient + " Doctor: " + doctor;
    }
}

