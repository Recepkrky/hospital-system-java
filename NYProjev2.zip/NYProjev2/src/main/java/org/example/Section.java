package org.example;

import java.io.Serializable ;
import java.util.LinkedList;

public class Section implements Serializable{
    private static final long serialVersionUID = 4L ;

    private final int id ;
    private String name ;
    private LinkedList<Doctor> doctors ;

    public Section(int id) {
        this.id = id;
        doctors = new LinkedList<>();
    }
    public Section(int id ,String name ) {
        this.id = id;
        doctors = new LinkedList<>();
        this.name = name ;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public LinkedList<Doctor> getDoctorList() {
        return doctors;
    }

    public void listDoctors(){
        System.out.println("__________________DOCTORS__________________");

        for(Doctor doctor : doctors){
            System.out.println(doctor);
        }
    }

    public Doctor getDoctor(int diploma_id) throws IDException{
        for(Doctor doctor : doctors){
            if(doctor.getDiploma_id() == diploma_id){
                //System.out.println("Doctor founded");
                return doctor;
            }
        }
        throw new IDException("-- This diplomaID couldn't find--");
    }

    public void addDoctor (Doctor doctor) throws  DuplicateInfoException{
        for(Doctor dctr : doctors){
            if(doctor.getDiploma_id() == dctr.getDiploma_id()){
                throw new  DuplicateInfoException("Two doctor has a same ID .") ;
            }
        }
        if(doctors.add(doctor)){
            System.out.println("Doktor ekleme islemi basarili" );
        }
    }

    public void removeDoctor (int doctorID) {
        for(Doctor dctr : doctors){
            if(doctorID == dctr.getDiploma_id()){
                doctors.remove(dctr);
            }
        }

    }

    @Override
    public String toString() {
        return " Section " + " doctors=" + doctors +
                ", id=" + id +
                ", name='" + name ;
    }
}
