package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SectionTest {
    @Test
    void testAddAndGetDoctor() throws IDException, DuplicateInfoException {
        // Test verileri
        Doctor doctor1 = new Doctor("Dr. Alice", 123456789L, 101, 10);
        Doctor doctor2 = new Doctor("Dr. Bob", 987654321L, 102, 15);

        // Section nesnesi oluştur
        Section section = new Section(201, "Cardiology");

        // Doktor ekle
        section.addDoctor(doctor1);
        section.addDoctor(doctor2);

        // Kontroller
        assertEquals(2, section.getDoctorList().size(), "Two doctors should be added to the section");
        assertEquals(doctor1, section.getDoctor(101), "Doctor with ID 101 should match doctor1");
        assertEquals(doctor2, section.getDoctor(102), "Doctor with ID 102 should match doctor2");

        // Aynı ID'ye sahip bir doktor ekleme (hata beklenir)
        Doctor duplicateDoctor = new Doctor("Dr. Charlie", 123456789L, 101, 20);
        assertThrows(DuplicateInfoException.class, () -> section.addDoctor(duplicateDoctor), "Adding a doctor with duplicate ID should throw DuplicateInfoException");

        // Geçersiz bir ID ile doktor arama (hata beklenir)
        assertThrows(IDException.class, () -> section.getDoctor(999), "Searching for a non-existent doctor ID should throw IDException");
    }
    @Test
    void testConstructorAndGetters() {
        // Test verileri
        int sectionId = 101;
        String sectionName = "Radiology";

        // Section nesnesi oluştur
        Section section = new Section(sectionId, sectionName);

        // Kontroller
        assertEquals(sectionId, section.getId(), "Section ID should match the given value");
        assertEquals(sectionName, section.getName(), "Section name should match the given value");
        assertNotNull(section.getDoctorList(), "Doctor list should be initialized");
        assertEquals(0, section.getDoctorList().size(), "Doctor list should initially be empty");
    }
}