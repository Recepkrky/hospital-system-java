package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PatientTest {

    @Test
    void testConstructorAndGetters() {
        // Test için bir Patient oluştur
        String name = "John Doe";
        long nationalId = 123456789L;

        Patient patient = new Patient(name, nationalId);

        // Kontroller
        assertEquals(name, patient.getName(), "Patient name should match the given value");
        assertEquals(nationalId, patient.getNational_id(), "Patient national ID should match the given value");
    }
    @Test
    void testEquality() {
        // İki aynı Patient nesnesi oluştur
        Patient patient1 = new Patient("Jane Smith", 987654321L);
        Patient patient2 = new Patient("Jane Smith", 987654321L);

        // Farklı bir Patient nesnesi oluştur
        Patient patient3 = new Patient("Jack Brown", 123123123L);

        // Eşitlik kontrolleri
        assertEquals(patient1.getName(), patient2.getName(), "Patients with the same name should be equal");
        assertEquals(patient1.getNational_id(), patient2.getNational_id(), "Patients with the same ID should be equal");

        // Farklılık kontrolleri
        assertNotEquals(patient1.getName(), patient3.getName(), "Patients with different names should not be equal");
        assertNotEquals(patient1.getNational_id(), patient3.getNational_id(), "Patients with different IDs should not be equal");
    }


}