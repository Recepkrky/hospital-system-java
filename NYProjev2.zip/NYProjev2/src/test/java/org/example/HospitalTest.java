package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class HospitalTest {
    @Test
    void testConstructorAndAddSection() {
        // Hospital oluştur
        int hospitalId = 101;
        String hospitalName = "City Hospital";
        Hospital hospital = new Hospital(hospitalId, hospitalName);

        // Constructor testi
        assertEquals(hospitalId, hospital.getId(), "Hospital ID should match");
        assertEquals(hospitalName, hospital.getName(), "Hospital name should match");
        assertTrue(hospital.getSections().isEmpty(), "Sections list should be empty initially");

        // Section ekle
        Section section1 = new Section(1, "Cardiology");
        Section section2 = new Section(2, "Neurology");

        assertTrue(hospital.addSection(section1), "Section 1 should be added successfully");
        assertTrue(hospital.addSection(section2), "Section 2 should be added successfully");
        assertEquals(2, hospital.getSections().size(), "Sections list size should be 2");

        // Aynı ID'ye sahip bir section eklemeyi test et
        Section duplicateSection = new Section(1, "Duplicate Cardiology");
        assertThrows(DuplicateInfoException.class, () -> hospital.addSection(duplicateSection), "Adding a section with duplicate ID should throw DuplicateInfoException");
    }

    @Test
    void testGetSectionAndSetName() throws IDException {
        // Hospital oluştur
        int hospitalId = 303;
        String initialName = "General Hospital";
        String newName = "Specialized Hospital";
        Hospital hospital = new Hospital(hospitalId, initialName);

        // Hastane ismini kontrol et
        assertEquals(initialName, hospital.getName(), "Initial hospital name should match");

        // Hastane ismini değiştir
        hospital.setName(newName);
        assertEquals(newName, hospital.getName(), "Hospital name should be updated");

        // Section ekle
        Section section1 = new Section(1, "Emergency");
        Section section2 = new Section(2, "Radiology");
        hospital.addSection(section1);
        hospital.addSection(section2);

        // ID ile section bulmayı test et
        assertEquals(section1, hospital.getSection(1), "Section with ID 1 should be returned");
        assertEquals(section2, hospital.getSection(2), "Section with ID 2 should be returned");

        // Geçersiz ID için exception testi
        assertThrows(IDException.class, () -> hospital.getSection(99), "Invalid section ID should throw IDException");
    }
}
