package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DoctorTest {
    @Test
    void testConstructor() {
        // Test için bir doktor oluştur
        String name = "Dr. John";
        long nationalId = 123456789L;
        int diplomaId = 101;
        int maxPatientsPerDay = 20;

        Doctor doctor = new Doctor(name, nationalId, diplomaId, maxPatientsPerDay);

        // Kontroller
        assertEquals(name, doctor.getName(), "Doctor name should match");
        assertEquals(nationalId, doctor.getNational_id(), "National ID should match");
        assertEquals(diplomaId, doctor.getDiploma_id(), "Diploma ID should match");
        assertEquals(maxPatientsPerDay, doctor.getSchedule().getMaxPatientPerDay(), "Max patients per day should match");
    }
    @Test
    void testSetScheduleAndToString() {
        // Test için bir doktor oluştur
        String name = "Dr. Jane";
        long nationalId = 987654321L;
        int diplomaId = 202;
        int maxPatientsPerDay = 15;

        Doctor doctor = new Doctor(name, nationalId, diplomaId, maxPatientsPerDay);

        // Yeni bir program (schedule) oluştur ve doktora ata
        Schedule newSchedule = new Schedule(10); // Yeni bir maxPatientsPerDay ile
        doctor.setSchedule(newSchedule);

        // Kontroller
        assertEquals(doctor, newSchedule.getDoctor(), "Schedule should be assigned to the correct doctor");
        assertEquals(newSchedule, doctor.getSchedule(), "Schedule should match the one set");

        // toString metodunu test et
        String expectedString = "Doctor's Name: Dr. Jane National ID: 987654321 Diploma ID :202";
        assertEquals(expectedString, doctor.toString(), "toString method output should match expected format");
    }




}