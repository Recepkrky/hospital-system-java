package org.example;

import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;


class ScheduleTest {

    @Test
    void testAddRendezvous() {
        // Test verileri
        Doctor doctor = new Doctor("Dr. Alice", 123456789L, 101, 5);
        Patient patient1 = new Patient("John Doe", 987654321L);
        Patient patient2 = new Patient("Jane Smith", 112233445L);

        // Schedule oluştur ve doktora ata
        Schedule schedule = new Schedule(1); // Maksimum 1 hasta
        schedule.setDoctor(doctor);

        // İlk randevu ekleme
        Date date = new Date();
        assertTrue(schedule.addRendezvous(patient1, date), "First rendezvous should be added successfully");

        // Maksimum hasta sınırını test et
        assertFalse(schedule.addRendezvous(patient2, date), "Adding another rendezvous on the same day should fail due to max patient limit");
    }
    @Test
    void testConstructorAndGetters() {
        // Test için bir Schedule nesnesi oluştur
        int maxPatients = 5;
        Schedule schedule = new Schedule(maxPatients);

        // Kontroller
        assertNotNull(schedule.getSessions(), "Sessions list should be initialized");
        assertEquals(0, schedule.getSessions().size(), "Sessions list should be empty initially");
        assertEquals(maxPatients, schedule.getMaxPatientPerDay(), "Max patients per day should match the given value");
        assertNull(schedule.getDoctor(), "Doctor should be null initially");
    }
}