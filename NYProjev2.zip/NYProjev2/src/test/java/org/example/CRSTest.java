package org.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;

class CRSTest {

    private CRS crs;
    private long patientID = 12345L;
    private long patientID2 = 123456L;
    private long patientID3 = 1234L;
    private long patientID4 = 123L;
    private int hospitalID = 101;
    private int hospitalID2 = 102;
    private int sectionID = 201;
    private int sectionID2 = 202;
    private int diplomaID = 301;
    private int diplomaID2 = 302;
    private int diplomaID3 = 303;
    private Date desiredDate = new Date();

    @BeforeEach
    void setUp() {
        crs = new CRS();  // Yeni bir CRS nesnesi oluşturuluyor//

        // Testler başlamadan önce her testten önce çalışacak kodu buraya yazın.

    }

    @Test
    void testFindPatientByID_GUIMode() {
        // GUI modunda, istisna atılmamalıdır.
        CRS.setGUIMode(true);

        // Yeni bir hasta ekliyoruz.
        Patient patient = new Patient("John Doe", patientID);
        crs.getPatients().put(patientID, patient);

        // Hasta bulunduğunda, istisna fırlatılmamalı
        assertDoesNotThrow(() -> {
            Patient foundPatient = CRS.findPatientByID(crs.getPatients(), patientID);
            assertEquals(patient, foundPatient);
        });
    }

    @Test
    void testFindPatientByID_NonGUIMode() {
        // GUI modunda değilken, istisna atılmalıdır.
        CRS.setGUIMode(false);

        // Test için hasta yok
        assertThrows(IDException.class, () -> {
            CRS.findPatientByID(crs.getPatients(), patientID);
        });
    }

    @Test
    void testFindHospitalByID_GUIMode() {
        // GUI modunda, istisna atılmamalıdır.
        CRS.setGUIMode(true);

        // Yeni bir hastane ekliyoruz
        Hospital hospital = new Hospital(hospitalID);
        crs.getHospitals().put(hospitalID, hospital);

        // Hastane bulunduğunda, istisna fırlatılmamalı
        assertDoesNotThrow(() -> {
            Hospital foundHospital = CRS.findHospitalById(crs.getHospitals(), hospitalID);
            assertEquals(hospital, foundHospital);
        });
    }

    @Test
    void testFindHospitalByID_NonGUIMode() {
        // GUI modunda değilken, istisna atılmalıdır.
        CRS.setGUIMode(false);

        // Test için hastane yok
        assertThrows(IDException.class, () -> {
            CRS.findHospitalById(crs.getHospitals(), hospitalID);
        });
    }

    @Test
    void testMakeRendezvous_GUIMode() {
        // GUI modunda, hasta ve hastane eklenmeli ve randevu alınmalıdır.
        CRS.setGUIMode(true);

        Patient patient = new Patient("John Doe", patientID);
        crs.getPatients().put(patientID, patient);

        Hospital hospital = new Hospital(hospitalID);
        crs.getHospitals().put(hospitalID, hospital);

        Doctor doctor16 = new Doctor("Recep" , 22242,301 , 1);
        Section section16 = new Section(sectionID);
        section16.addDoctor(doctor16);
        hospital.addSection(section16);

        Schedule schedule = new Schedule(1);
        doctor16.setSchedule(schedule);
        // Randevu alınmalıdır.
        boolean success = crs.makeRandezvous(patientID, hospitalID, sectionID, diplomaID, desiredDate);
        assertTrue(success);
    }

    @Test
    void testMakeRendezvous_NonGUIMode() {
        // GUI modunda değilken, randevu alınmalı ve hata mesajı gösterilmelidir.
        CRS.setGUIMode(false);

        Patient patient = new Patient("John Doe", patientID);
        crs.getPatients().put(patientID, patient);

        Patient patient2 = new Patient("John Doe2", patientID2);
        crs.getPatients().put(patientID2, patient2);

        Hospital hospital = new Hospital(hospitalID);
        crs.getHospitals().put(hospitalID, hospital);

        Doctor doctor16 = new Doctor("Recep" , 22242,301,1);
        Section section16 = new Section(sectionID);

        section16.addDoctor(doctor16);
        hospital.addSection(section16);

      Schedule schedule = new Schedule(1);
        doctor16.setSchedule(schedule);
       // schedule.addRendezvous(patient,desiredDate);
      //  schedule.addRendezvous(patient2,desiredDate);

        // Randevu alınmalıdır ancak max hasta sınırına takılabilir.
        boolean success = crs.makeRandezvous(patientID, hospitalID, sectionID, diplomaID, desiredDate);
        boolean success2 =crs.makeRandezvous(patientID2, hospitalID, sectionID, diplomaID, desiredDate);

        assertFalse(success2);
    }

    @Test
    void testSerialization() throws ClassNotFoundException {
        // CRS objesini dosyaya serileştir
        String path = "crs_data.ser";
        crs.saveTablesToDisk(path);

        // Dosyadan CRS objesini geri yükle
        CRS loadedCRS = CRS.loadTablesToDisk(path);

        // Geri yüklenen CRS objesi null olmamalıdır
        assertNotNull(loadedCRS);
    }

    @Test
    void testListDoctor(){
        Doctor doctor16 = new Doctor("Recep" , 22242,301,1);
        Doctor doctor17 = new Doctor("Recep2" , 22243,302,1);
        Doctor doctor18 = new Doctor("Recep3" , 22244,303,1);
        Section section16 = new Section(sectionID);
        section16.addDoctor(doctor16);
        section16.addDoctor(doctor17);
        section16.addDoctor(doctor18);

        section16.listDoctors();

    }

    @Test
    void test3Doctor4Patient_NonGUIMode(){
        // GUI modunda değilken, randevu alınmalı ve hata mesajı gösterilmelidir.
        CRS.setGUIMode(false);

        Patient patient = new Patient("John Doe", patientID);
        crs.getPatients().put(patientID, patient);

        Patient patient2 = new Patient("John Doe2", patientID2);
        crs.getPatients().put(patientID2, patient2);

        Patient patient3 = new Patient("John Doe3", patientID3);
        crs.getPatients().put(patientID3, patient3);

        Patient patient4 = new Patient("John Doe4", patientID4);
        crs.getPatients().put(patientID4, patient4);

        Hospital hospital = new Hospital(hospitalID);
        crs.getHospitals().put(hospitalID, hospital);

        Doctor doctor16 = new Doctor("Recep" , 22242,301,1);
        Section section16 = new Section(sectionID);

        Doctor doctor17 = new Doctor("Recep2" , 22243,302,1);
        Section section17 = new Section(sectionID2);

        Doctor doctor18 = new Doctor("Recep3" , 22244,303,1);

        hospital.addSection(section16);
        section16.addDoctor(doctor16);
        section16.addDoctor(doctor18);

        hospital.addSection(section17);
        section17.addDoctor(doctor17);

        Schedule schedule = new Schedule(1);
        Schedule schedule2 = new Schedule(1);
        Schedule schedule3 = new Schedule(1);

        doctor16.setSchedule(schedule);
        doctor17.setSchedule(schedule2);
        doctor18.setSchedule(schedule3);

        // schedule.addRendezvous(patient,desiredDate);
        //  schedule.addRendezvous(patient2,desiredDate);

        // Randevu alınmalıdır ancak max hasta sınırına takılabilir.
        boolean success = crs.makeRandezvous(patientID, hospitalID, sectionID, diplomaID, desiredDate);
        boolean success2 =crs.makeRandezvous(patientID2, hospitalID, sectionID, diplomaID, desiredDate);
        boolean success3 =crs.makeRandezvous(patientID3, hospitalID, sectionID2, diplomaID2, desiredDate);
        boolean success4 =crs.makeRandezvous(patientID4, hospitalID, sectionID, diplomaID3, desiredDate);

        //System.out.println(hospital);

        System.out.println(hospital.getSection(sectionID));
        System.out.println(hospital.getSection(sectionID2));

        assertFalse(success2);

    }

    @Test
    void test2Hospital_NonGUIMode(){
        // GUI modunda değilken, randevu alınmalı ve hata mesajı gösterilmelidir.
        CRS.setGUIMode(false);


        Patient patient = new Patient("John Doe", patientID);
        crs.getPatients().put(patientID, patient);

        Patient patient2 = new Patient("John Doe2", patientID2);
        crs.getPatients().put(patientID2, patient2);

        Patient patient3 = new Patient("John Doe3", patientID3);
        crs.getPatients().put(patientID3, patient3);

        Patient patient4 = new Patient("John Doe4", patientID4);
        crs.getPatients().put(patientID4, patient4);

        Hospital hospital = new Hospital(hospitalID);
        crs.getHospitals().put(hospitalID, hospital);

        Hospital hospital2 = new Hospital(hospitalID2);
        crs.getHospitals().put(hospitalID2, hospital2);

        Doctor doctor16 = new Doctor("Recep" , 22242,301,1);
        Section section16 = new Section(sectionID);

        Doctor doctor17 = new Doctor("Recep2" , 22243,302,1);
        Section section17 = new Section(sectionID2);

        Doctor doctor18 = new Doctor("Recep3" , 22244,303,1);

        hospital.addSection(section16);
        section16.addDoctor(doctor16);
        section16.addDoctor(doctor18);

        hospital2.addSection(section17);
        section17.addDoctor(doctor17);



        Schedule schedule = new Schedule(1);
        Schedule schedule2 = new Schedule(1);
        Schedule schedule3 = new Schedule(1);

        doctor16.setSchedule(schedule);
        doctor17.setSchedule(schedule2);
        doctor18.setSchedule(schedule3);

        // schedule.addRendezvous(patient,desiredDate);
        //  schedule.addRendezvous(patient2,desiredDate);

        // Randevu alınmalıdır ancak max hasta sınırına takılabilir.
        boolean success = crs.makeRandezvous(patientID, hospitalID, sectionID, diplomaID, desiredDate);
        boolean success2 =crs.makeRandezvous(patientID2, hospitalID, sectionID, diplomaID, desiredDate);
        boolean success3 =crs.makeRandezvous(patientID3, hospitalID2, sectionID2, diplomaID2, desiredDate);
        boolean success4 =crs.makeRandezvous(patientID4, hospitalID, sectionID, diplomaID3, desiredDate);

        System.out.println(hospital);
        System.out.println(hospital2);
        //Yazdirdigimda tum ciktilari dogru bir sekilde veriyor .
       // System.out.println(hospital.getSection(sectionID));
       // System.out.println(hospital.getSection(sectionID2));

        assertTrue(success3);
    }
    }




