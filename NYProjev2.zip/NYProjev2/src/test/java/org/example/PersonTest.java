package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PersonTest {
    @Test
    void testAreIDequals() {
        // Test verileri
        long personID1 = 123456789L;
        long personID2 = 987654321L;

        // Eşit ID'leri test et
        assertTrue(Person.areIDequals(personID1, 123456789L), "IDs should be equal");

        // Farklı ID'leri test et
        assertFalse(Person.areIDequals(personID1, personID2), "IDs should not be equal");
    }
    @Test
    void testConstructorAndGetters() {
        // Test için bir Person oluştur
        String name = "Alice";
        long nationalId = 987654321L;

        Person person = new Person(name, nationalId);

        // Kontroller
        assertEquals(name, person.getName(), "Person name should match the given value");
        assertEquals(nationalId, person.getNational_id(), "Person national ID should match the given value");
    }
}