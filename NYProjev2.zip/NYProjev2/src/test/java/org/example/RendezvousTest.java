package org.example;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

class RendezvousTest {
    @Test
    void testSetters() {
        // Başlangıç verileri
        Date initialDate = new Date();
        Patient initialPatient = new Patient("Bob", 987654321L);
        Doctor initialDoctor = new Doctor("Dr. Jane", 123456789L, 102, 15);

        // Rendezvous oluştur
        Rendezvous rendezvous = new Rendezvous(initialDate, initialPatient, initialDoctor);

        // Yeni veriler
        Date newDate = new Date(System.currentTimeMillis() + 100000L); // Şimdiki zamandan ileri bir tarih
        Patient newPatient = new Patient("Charlie", 112233445L);
        Doctor newDoctor = new Doctor("Dr. Smith", 998877665L, 103, 20);

        // Setter metodlarını test et
        rendezvous.setDateTime(newDate);
        rendezvous.setPatient(newPatient);
        rendezvous.setDoctor(newDoctor);

        // Kontroller
        assertEquals(newDate, rendezvous.getDateTime(), "DateTime should be updated to the new value");
        assertEquals(newPatient, rendezvous.getPatient(), "Patient should be updated to the new value");
        assertEquals(newDoctor, rendezvous.getDoctor(), "Doctor should be updated to the new value");
    }
    @Test
    void testConstructorAndGetters() {
        // Test verileri
        Date dateTime = new Date();
        Patient patient = new Patient("Alice", 123456789L);
        Doctor doctor = new Doctor("Dr. John", 987654321L, 101, 10);

        // Rendezvous oluştur
        Rendezvous rendezvous = new Rendezvous(dateTime, patient, doctor);

        // Kontroller
        assertEquals(dateTime, rendezvous.getDateTime(), "DateTime should match the given value");
        assertEquals(patient, rendezvous.getPatient(), "Patient should match the given value");
        assertEquals(doctor, rendezvous.getDoctor(), "Doctor should match the given value");
    }
}